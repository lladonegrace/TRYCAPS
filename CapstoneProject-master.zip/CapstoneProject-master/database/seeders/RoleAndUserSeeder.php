<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class RoleAndUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create Roles
        $focalPersonRole = Role::create([
            'RoleName' => 'Focal Person',
            'Description' => 'Handles focal person responsibilities'
        ]);

        $provincialOfficeRole = Role::create([
            'RoleName' => 'Provincial Office',
            'Description' => 'Manages provincial office operations'
        ]);

        $pdoRole = Role::create([
            'RoleName' => 'Project Development Officer',
            'Description' => 'Oversees project development'
        ]);

        $rtsRole = Role::create([
            'RoleName' => 'RTS',
            'Description' => 'Regional Technical Support'
        ]);

        // Create Users
        $focalPerson = User::create([
            'name' => 'Focal Person User',
            'email' => 'focal@example.com',
            'password' => Hash::make('password123'),
            'email_verified_at' => now()
        ]);

        $provincialOffice = User::create([
            'name' => 'Provincial Office User',
            'email' => 'provincial@example.com',
            'password' => Hash::make('password123'),
            'email_verified_at' => now()
        ]);

        $pdo = User::create([
            'name' => 'PDO User',
            'email' => 'pdo@example.com',
            'password' => Hash::make('password123'),
            'email_verified_at' => now()
        ]);

        $rts = User::create([
            'name' => 'RTS User',
            'email' => 'rts@example.com',
            'password' => Hash::make('password123'),
            'email_verified_at' => now()
        ]);

        // Assign Roles to Users
        DB::table('user_role')->insert([
            [
                'UserID' => $focalPerson->id,
                'RoleID' => $focalPersonRole->RoleID,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'UserID' => $provincialOffice->id,
                'RoleID' => $provincialOfficeRole->RoleID,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'UserID' => $pdo->id,
                'RoleID' => $pdoRole->RoleID,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'UserID' => $rts->id,
                'RoleID' => $rtsRole->RoleID,
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
} 
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissions = [
            ['PermissionName' => 'View'],
            ['PermissionName' => 'Edit'],
            ['PermissionName' => 'Delete'],
            ['PermissionName' => 'Create'],
        ];

        // Add timestamps to each permission
        $timestamp = Carbon::now();
        $permissionsWithTimestamps = array_map(function ($permission) use ($timestamp) {
            $permission['created_at'] = $timestamp;
            $permission['updated_at'] = $timestamp;
            return $permission;
        }, $permissions);

        // Insert the data into the 'permissions' table
        DB::table('permissions')->insert($permissionsWithTimestamps);
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Office;

class OfficeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $offices = [
            [
                'OfficeName' => 'PCA Region V Office',
                'OfficeType' => 'Regional Office',
                'Location' => 'Legazpi City, Albay',
                'ContactInfo' => 'regionv@pca.gov.ph | (052) 481-1234',
                'HeadName' => 'Regional Director Juan Dela Cruz',
            ],
            [
                'OfficeName' => 'Albay PCA Provincial Office',
                'OfficeType' => 'Provincial Office',
                'Location' => 'Legazpi City, Albay',
                'ContactInfo' => 'albay@pca.gov.ph | (052) 481-5678',
                'HeadName' => 'Provincial Manager Maria Santos',
            ],
            [
                'OfficeName' => 'Camarines Norte PCA Provincial Office',
                'OfficeType' => 'Provincial Office',
                'Location' => 'Daet, Camarines Norte',
                'ContactInfo' => 'camarinesnorte@pca.gov.ph | (054) 721-9012',
                'HeadName' => 'Provincial Manager Pedro Reyes',
            ],
            [
                'OfficeName' => 'Camarines Sur PCA Provincial Office',
                'OfficeType' => 'Provincial Office',
                'Location' => 'Naga City, Camarines Sur',
                'ContactInfo' => 'camarinessur@pca.gov.ph | (054) 473-3456',
                'HeadName' => 'Provincial Manager Ana Garcia',
            ],
            [
                'OfficeName' => 'Sorsogon PCA Provincial Office',
                'OfficeType' => 'Provincial Office',
                'Location' => 'Sorsogon City, Sorsogon',
                'ContactInfo' => 'sorsogon@pca.gov.ph | (056) 211-7890',
                'HeadName' => 'Provincial Manager Carlos Mendoza',
            ],
            [
                'OfficeName' => 'Catanduanes PCA Provincial Office',
                'OfficeType' => 'Provincial Office',
                'Location' => 'Virac, Catanduanes',
                'ContactInfo' => 'catanduanes@pca.gov.ph | (052) 811-2345',
                'HeadName' => 'Provincial Manager Rosa Villanueva',
            ],
            [
                'OfficeName' => 'Masbate PCA Provincial Office',
                'OfficeType' => 'Provincial Office',
                'Location' => 'Masbate City, Masbate',
                'ContactInfo' => 'masbate@pca.gov.ph | (056) 333-6789',
                'HeadName' => 'Provincial Manager Luis Torres',
            ],
        ];

        foreach ($offices as $office) {
            Office::create($office);
        }
    }
} 
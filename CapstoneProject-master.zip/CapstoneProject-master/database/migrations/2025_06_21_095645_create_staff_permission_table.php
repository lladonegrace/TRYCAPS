<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('staff_permission', function (Blueprint $table) {
            $table->id('StaffPermissionID');
            $table->unsignedBigInteger('StaffID');
            $table->unsignedBigInteger('PermissionID');
            $table->timestamps();

            $table->foreign('StaffID')->references('StaffID')->on('staff')->onDelete('cascade');
            $table->foreign('PermissionID')->references('PermissionID')->on('permissions')->onDelete('cascade');
            
            // Ensure a staff member can only have one instance of each permission
            $table->unique(['StaffID', 'PermissionID']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('staff_permission');
    }
};

import "./bootstrap";
import "../css/app.css"; // Also ensure CSS is imported here for Vite to process



// If you are using Alpine via CDN, this app.js might be minimal.
// However, it's good practice to have Vite process your main CSS through it.

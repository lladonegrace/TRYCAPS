﻿<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'PCAppTrack') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
        
      
        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    
        <!-- Alpine.js -->
         
        <!-- Livewire Styles -->
        @livewireStyles
    </head>
    <body class="font-sans antialiased m-0 p-0 text-gray-900 min-h-screen" style="margin-top:-30px;">
        <div wire:loading class="fixed inset-0 z-[9999] flex items-center justify-center bg-white bg-opacity-75">
            <div class="h-16 w-16 animate-spin rounded-full border-4 border-solid border-green-500 border-t-transparent"></div>
        </div>
        
        <!-- Toast Notification Container -->
        <div 
            x-data="{ 
                show: false, 
                type: 'success', 
                message: '',
                timeout: null,
                showToast(detail) {
                    console.log('Toast notification received:', detail);
                    this.show = true;
                    
                    if (!detail) {
                        console.error('No detail provided for toast notification');
                        return;
                    }
                    
                    // Handle string input
                    if (typeof detail === 'string') {
                        this.message = detail;
                        this.type = 'info';
                    } 
                    // Handle array input (which happens with Livewire's dispatch)
                    else if (Array.isArray(detail)) {
                        const data = detail[0] || {};
                        this.type = data.type || 'success';
                        this.message = data.message || '';
                    }
                    // Handle object input
                    else {
                        this.type = detail.type || 'success';
                        this.message = detail.message || '';
                    }
                    
                    console.log('Toast displaying with:', {type: this.type, message: this.message});
                    
                    if (this.timeout) {
                        clearTimeout(this.timeout);
                    }
                    
                    this.timeout = setTimeout(() => {
                        this.show = false;
                    }, 4000);
                }
            }" 
            @notify.window="showToast($event.detail)"
            x-show="show" 
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 transform translate-y-2"
            x-transition:enter-end="opacity-100 transform translate-y-0"
            x-transition:leave="transition ease-in duration-500"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform translate-y-2"
            @click="show = false"
            class="fixed bottom-6 right-6 z-50 flex items-center p-4 mb-4 w-full max-w-sm rounded-lg shadow border-l-4"
            :class="{
                'bg-green-100 border-green-500 text-gray-800': type === 'success',
                'bg-red-100 border-red-500 text-gray-800': type === 'error',
                'bg-blue-100 border-blue-500 text-gray-800': type === 'info',
                'bg-yellow-100 border-yellow-500 text-gray-800': type === 'warning'
            }"
            style="display: none;"
            role="alert"
        >
            <div class="inline-flex items-center justify-center flex-shrink-0 w-8 h-8 rounded-full"
                :class="{
                    'text-green-600': type === 'success',
                    'text-red-600': type === 'error',
                    'text-blue-600': type === 'info',
                    'text-yellow-600': type === 'warning'
                }">
                <!-- Different icons for different notification types -->
                <template x-if="type === 'success'">
                    <span class="material-symbols-outlined">check_circle</span>
                </template>
                <template x-if="type === 'error'">
                    <span class="material-symbols-outlined">error</span>
                </template>
                <template x-if="type === 'info'">
                    <span class="material-symbols-outlined">info</span>
                </template>
                <template x-if="type === 'warning'">
                    <span class="material-symbols-outlined">warning</span>
                </template>
            </div>
            <div class="ml-3 text-sm font-medium" x-text="message"></div>
            <button type="button" class="ml-auto -mx-1.5 -my-1.5 rounded-lg focus:ring-2 p-1.5 inline-flex h-8 w-8 text-gray-500 hover:text-gray-700" 
                @click="show = false">
                <span class="material-symbols-outlined text-sm">close</span>
            </button>
        </div>

            @auth
                {{ $slot ?? '' }}
                @yield('content')
            @else
                <script>window.location = "{{ route('login') }}";</script>
            @endauth

        <!-- Livewire Scripts -->
        @livewireScripts
    </body>
</html>

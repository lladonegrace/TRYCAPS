<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - {{ config('app.name', 'Laravel') }}</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lemon&display=swap" rel="stylesheet">

    <style>
        @keyframes subtlePulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.85; }
        }

        .animate-pulse-subtle {
            animation: subtlePulse 3s ease-in-out infinite;
        }

        @keyframes gradientBg {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
    </style>
    
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-white-100 font-['Montserrat']">
    <div class="min-h-screen flex items-center justify-center py-10 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-green-50 to-white">
        <div class="max-w-4xl w-full bg-white rounded-lg shadow-xl overflow-hidden transform transition-all duration-300 hover:scale-[1.01]">
            <div class="flex flex-col md:flex-row md:h-[38rem]">
                <!-- Illustration - now visible on mobile above form -->
                <div class="w-full md:w-3/5 bg-green-50 h-48 md:h-full relative overflow-hidden">
                    <div class="absolute inset-0 bg-gradient-to-br from-green-100/30 to-transparent"></div>
                    <img src="{{ asset('images/1.png') }}" alt="Login illustration" class="w-full h-full object-cover transition-all duration-700 hover:scale-105">
                </div>
                
                <!-- Login form -->
                <div class="w-full md:w-1/2 p-8 flex items-start bg-white relative">
                    <div class="absolute top-0 left-0 w-full h-12 bg-gradient-to-b from-gray-100/50 to-transparent"></div>
                    <div class="w-full relative z-10 pt-4">
                        <div class="text-center mb-8">
                            <h2 class="text-2xl font-bold text-lime-800 mb-2">Welcome To</h2>
                            <h1 class="text-3xl font-bold text-green-500 font-['Lemon'] tracking-wider animate-pulse-subtle relative inline-block">
                                <span class="relative inline-block">
                                    PCAppTrack!
                                    <span class="absolute -bottom-1 left-0 w-full h-1 bg-green-300 rounded-full transform origin-left transition-all duration-300 hover:scale-x-110"></span>
                                </span>
                            </h1>
                        </div>
                        <p class="text-sm text-gray-600 text-center mb-10">Log in your credentials</p>

                    <!-- Session Status -->
                    <x-login-session-status class="mb-4" :status="session('status')" />

                    <form method="POST" action="{{ route('login') }}" class="space-y-4">
                        @csrf

                        <!-- Email Address -->
                        <div class="mb-6">
                            <label for="email" class="block text-sm font-medium text-green-600 mb-2">Email Address</label>
                            <input id="email" name="email" type="email" required 
                                class="appearance-none rounded-md relative block w-full px-3 py-3 border border-gray-200 placeholder-gray-400 text-gray-900 focus:outline-none focus:ring-green-500 focus:border-green-500 focus:z-10 sm:text-sm"
                                placeholder="youremail@gmail.com"
                                value="{{ old('email') }}"
                            >
                            <x-login-error :messages="$errors->get('email')" class="mt-2" />
                        </div>

                        <!-- Password -->
                        <div class="relative">
                            <label for="password" class="block text-sm font-medium text-green-600 mb-2">Password</label>
                            <input id="password" name="password" type="password" required
                                class="appearance-none rounded-md relative block w-full px-3 py-3 pr-10 border border-gray-200 placeholder-gray-400 text-gray-900 focus:outline-none focus:ring-green-500 focus:border-green-500 focus:z-10 sm:text-sm"
                                placeholder="*************"
                            >
                            <button type="button" 
                                onclick="togglePassword()"
                                class="absolute inset-y-0 right-0 flex items-center pr-3 focus:outline-none z-20 mt-7"
                            >
                                <!-- Eye Closed (Default - Password Hidden) -->
                                <svg id="eye-closed" class="h-4 w-4 text-gray-400 hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 11-4.243-4.243m4.242 4.242L9.88 9.88"/>
                                </svg>
                                <!-- Eye Open (Password Visible) -->
                                <svg id="eye-open" class="h-4 w-4 text-gray-400 hover:text-gray-600 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </button>
                            <x-login-error :messages="$errors->get('password')" class="mt-2" />
                        </div>

                        <!-- Remember Me -->
                        <div class="flex items-center mt-2" style="margin-top: 16px;">
                            <input id="remember_me" name="remember" type="checkbox" 
                                class="h-3.5 w-3.5 text-green-500 focus:ring-green-500 border-gray-300 rounded">
                            <label for="remember_me" class="ml-2 block text-xs text-gray-500">
                                Remember me
                            </label>
                        </div>

                        <div class="mt-8">
                            <button type="submit" class="group relative w-full flex justify-center py-2 px-4 border border-transparent h-10 text-sm font-medium rounded-md text-white bg-green-500 hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all duration-150 ease-in-out hover:shadow-lg transform hover:-translate-y-0.5">
                                Log In
                            </button>
                        </div>
                        
                        <!-- Forgot Password Link -->
                        <div class="mt-3 text-center">
                            <button type="button" 
                                    onclick="document.getElementById('forgotPasswordModal').classList.remove('hidden')"
                                    class="text-xs text-green-600 hover:text-green-700 hover:underline">
                                Forgot password or having trouble logging in?
                            </button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div id="forgotPasswordModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-lg shadow-xl max-w-lg w-5/6 p-8">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-xl font-medium text-gray-900">Need Assistance?</h3>
                <button type="button" onclick="document.getElementById('forgotPasswordModal').classList.add('hidden')" 
                        class="text-gray-400 hover:text-gray-500 focus:outline-none">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <div class="space-y-5">
                <div class="p-5 bg-green-50 rounded-lg border border-green-100">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-base font-medium text-green-800">Contact your Regional Focal Person</h3>
                            <div class="mt-2 text-sm text-green-700">
                                <p>Please contact your designated Regional Focal Person for assistance with:</p>
                                <ul class="list-disc list-inside mt-2 space-y-1.5">
                                    <li>Password resets</li>
                                    <li>Account unlocks</li>
                                    <li>Login issues</li>
                                    <li>Account updates</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-sm text-gray-500 px-2">
                    <p>Your Regional Focal Person is the administrator responsible for managing user accounts in the system.</p>
                </div>
                <div class="pt-4 border-t border-gray-200">
                    <button type="button" 
                            onclick="document.getElementById('forgotPasswordModal').classList.add('hidden')"
                            class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        I understand
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const eyeOpen = document.getElementById('eye-open');
            const eyeClosed = document.getElementById('eye-closed');
            
            if (passwordInput.type === 'password') {
                // Show password - show eye-open, hide eye-closed
                passwordInput.type = 'text';
                eyeOpen.classList.remove('hidden');
                eyeClosed.classList.add('hidden');
            } else {
                // Hide password - show eye-closed, hide eye-open
                passwordInput.type = 'password';
                eyeOpen.classList.add('hidden');
                eyeClosed.classList.remove('hidden');
            }
        }

        // Close modal when clicking outside of it
        document.addEventListener('click', function(event) {
            const modal = document.getElementById('forgotPasswordModal');
            const modalContent = modal.querySelector('div');
            
            if (modal.classList.contains('hidden')) return;
            
            // Check if click is outside the modal content
            if (!modalContent.contains(event.target) && modal.contains(event.target)) {
                modal.classList.add('hidden');
            }
        });

        // Allow ESC key to close the modal
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                document.getElementById('forgotPasswordModal').classList.add('hidden');
            }
        });
    </script>
</body>
</html>

<nav class="flex-1 overflow-y-auto pt-4">
    <div class="px-3 py-4">
        <ul class="space-y-2">
            @foreach($navigationItems as $item)
            <li>
                <a 
                    href="{{ route($item['route']) }}"
                    wire:navigate
                    class="block w-full"
                >
                    <div class="flex items-center justify-between p-3 rounded-lg {{ request()->routeIs($item['route']) ? 'bg-green-500 text-white' : 'text-gray-600 hover:bg-gray-100' }}">
                        <div class="flex items-center space-x-3">
                            <span class="material-symbols-outlined text-lg">
                                @if($item['icon'] === 'dashboard')
                                    dashboard
                                @elseif($item['icon'] === 'engineering')
                                    engineering
                                @elseif($item['icon'] === 'task')
                                    task_alt
                                @elseif($item['icon'] === 'account_balance')
                                    account_balance
                                @elseif($item['icon'] === 'description')
                                    description
                                @elseif($item['icon'] === 'rate_review')
                                    rate_review
                                @elseif($item['icon'] === 'pending_actions')
                                    pending_actions
                                @elseif($item['icon'] === 'task_alt')
                                    task_alt
                                @elseif($item['icon'] === 'assessment')
                                    assessment
                                @elseif($item['icon'] === 'schedule')
                                    schedule
                                @elseif($item['icon'] === 'grading')
                                    grading
                                @elseif($item['icon'] === 'support')
                                    support
                                @elseif($item['icon'] === 'analytics')
                                    analytics
                                @elseif($item['icon'] === 'apps')
                                    apps
                                @elseif($item['icon'] === 'inbox')
                                    inbox
                                @elseif($item['icon'] === 'mark_email_read')
                                    mark_email_read
                                @elseif($item['icon'] === 'assignment_ind')
                                    assignment_ind
                                @elseif($item['icon'] === 'monitoring')
                                    monitoring
                                @elseif($item['icon'] === 'manage_accounts')
                                    manage_accounts
                                @elseif($item['icon'] === 'fact_check')
                                    fact_check
                                @else
                                    dashboard
                                @endif
                            </span>
                            <span class="text-base {{ request()->routeIs($item['route']) ? 'font-bold' : 'font-medium' }}">{{ $item['name'] }}</span>
                        </div>
                    </div>
                </a>
            </li>
            @endforeach
        </ul>
    </div>
</nav> 
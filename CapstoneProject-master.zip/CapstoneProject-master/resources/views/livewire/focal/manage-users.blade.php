<div class="p-6">
    <!-- Header Section -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-700 mb-1">User and Staff Management</h1>
        <p class="text-gray-600">Manage offices, user accounts, staff lists and their roles.</p>
    </div>    <!-- Toast notifications are now handled by the layout -->

    <!-- Tab Navigation -->
    <div class="mb-6">
        <!-- Mobile Dropdown Navigation -->
        <div class="sm:hidden">
            <div x-data="{ open: false }" class="relative">
                <button 
                    @click="open = !open" 
                    class="flex items-center justify-between w-full px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined mr-2 align-middle">
                            {{ $activeTab === 'offices' ? 'business' : 
                              ($activeTab === 'users' ? 'person' : 
                              ($activeTab === 'staff' ? 'people' : 'security')) }}
                        </span>
                        <span>
                            {{ $activeTab === 'offices' ? 'Offices' : 
                              ($activeTab === 'users' ? 'Users' : 
                              ($activeTab === 'staff' ? 'Staff' : 'Login Attempts')) }}
                        </span>
                    </div>
                    <span class="material-symbols-outlined ml-2">arrow_drop_down</span>
                </button>

                <div 
                    x-show="open" 
                    @click.away="open = false"
                    x-transition:enter="transition ease-out duration-100"
                    x-transition:enter-start="transform opacity-0 scale-95"
                    x-transition:enter-end="transform opacity-100 scale-100"
                    x-transition:leave="transition ease-in duration-75"
                    x-transition:leave-start="transform opacity-100 scale-100"
                    x-transition:leave-end="transform opacity-0 scale-95"
                    class="absolute z-10 mt-1 w-full bg-white shadow-lg rounded-md ring-1 ring-black ring-opacity-5 focus:outline-none"
                    style="display: none;"
                >
                    <div class="py-1">
                        <button 
                            wire:click="setActiveTab('offices')"
                            @click="open = false"
                            class="flex items-center w-full px-4 py-2 text-sm {{ $activeTab === 'offices' ? 'bg-gray-100 text-green-600' : 'text-gray-700 hover:bg-gray-50' }}">
                            <span class="material-symbols-outlined mr-2 align-middle">business</span>
                            Offices
                        </button>
                        <button 
                            wire:click="setActiveTab('users')"
                            @click="open = false"
                            class="flex items-center w-full px-4 py-2 text-sm {{ $activeTab === 'users' ? 'bg-gray-100 text-green-600' : 'text-gray-700 hover:bg-gray-50' }}">
                            <span class="material-symbols-outlined mr-2 align-middle">person</span>
                            Users
                        </button>
                        <button 
                            wire:click="setActiveTab('staff')"
                            @click="open = false"
                            class="flex items-center w-full px-4 py-2 text-sm {{ $activeTab === 'staff' ? 'bg-gray-100 text-green-600' : 'text-gray-700 hover:bg-gray-50' }}">
                            <span class="material-symbols-outlined mr-2 align-middle">people</span>
                            Staff
                        </button>
                        <button 
                            wire:click="setActiveTab('login-attempts')"
                            @click="open = false"
                            class="flex items-center w-full px-4 py-2 text-sm {{ $activeTab === 'login-attempts' ? 'bg-gray-100 text-green-600' : 'text-gray-700 hover:bg-gray-50' }}">
                            <span class="material-symbols-outlined mr-2 align-middle">security</span>
                            Login Attempts
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Desktop Tab Navigation -->
        <nav class="hidden sm:flex space-x-8" aria-label="Tabs">
            <button 
                wire:click="setActiveTab('offices')"
                class="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm {{ $activeTab === 'offices' ? 'border-green-500 text-green-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
                <span class="material-symbols-outlined mr-2 align-middle">business</span>
                Offices
            </button>
            <button 
                wire:click="setActiveTab('users')"
                class="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm {{ $activeTab === 'users' ? 'border-green-500 text-green-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
                <span class="material-symbols-outlined mr-2 align-middle">person</span>
                Users
            </button>
            <button 
                wire:click="setActiveTab('staff')"
                class="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm {{ $activeTab === 'staff' ? 'border-green-500 text-green-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
                <span class="material-symbols-outlined mr-2 align-middle">people</span>
                Staff
            </button>
            <button 
                wire:click="setActiveTab('login-attempts')"
                class="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm {{ $activeTab === 'login-attempts' ? 'border-green-500 text-green-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
                <span class="material-symbols-outlined mr-2 align-middle">security</span>
                Login Attempts
            </button>
        </nav>
    </div>

    <!-- Offices Tab -->
    @if($activeTab === 'offices')
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <!-- Header with Search, Filters and Add Button -->
            <div class="p-6 border-b border-gray-200">
                <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-semibold text-gray-800">Office Management</h2>
                        <p class="text-sm text-gray-600 mt-1">Manage provincial and regional offices</p>
                    </div>
                    
                    <!-- Search and Filters Row -->
                    <div class="flex flex-col sm:flex-row gap-3 lg:items-center">
                        <!-- Search Bar -->
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="material-symbols-outlined text-gray-400 text-sm">search</span>
                            </div>
                            <input type="text" 
                                   wire:model.live.debounce.300ms="search"
                                   class="block w-full sm:w-64 pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                                   placeholder="Search offices...">
                        </div>                        <!-- Office Type Filter -->
                        <div class="min-w-[180px]">
                            <select wire:model.live="officeTypeFilter" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                                <option value="">All Types</option>
                                <option value="Provincial Office">Provincial Office</option>
                                <option value="Regional Office">Regional Office</option>
                            </select>
                        </div>

                        <!-- Clear Filters Button -->
                        @if($search || $officeTypeFilter)
                            <button wire:click="clearFilters" 
                                    class="px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                <span class="material-symbols-outlined text-sm">clear</span>
                            </button>
                        @endif

                        <!-- Add Office Button -->
                        <button 
                            wire:click="openOfficeModal"
                            class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap">
                            <span class="material-symbols-outlined mr-2 text-sm">add</span>
                            Add Office
                        </button>
                    </div>
                </div>
            </div>

            <!-- Mobile Card View (Offices) -->
            <div class="block sm:hidden">
                @forelse($offices as $office)
                    <div class="border-b border-gray-200 p-6">
                        <div class="space-y-3">
                            <div class="font-medium text-gray-700">{{ $office->OfficeName }}</div>
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium {{ $office->OfficeType === 'Regional Office' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800' }}">
                                    {{ $office->OfficeType }}
                                </span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    {{ $office->staff->count() }} staff
                                </span>
                            </div>
                            
                            @if($office->Location)
                                <div class="text-sm text-gray-600 flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                    </svg>
                                    {{ $office->Location }}
                                </div>
                            @endif                            @if($office->HeadName)
                                <div class="text-sm text-gray-600 flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
                                    </svg>
                                    {{ $office->HeadName }}
                                </div>
                            @endif
                            @if($office->ContactInfo)
                                <div class="text-sm text-gray-500">{{ $office->ContactInfo }}</div>
                            @endif
                            <div class="flex gap-2 pt-2">
                                <button 
                                    wire:click="editOffice({{ $office->OfficeID }})"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">edit</span>
                                    Edit
                                </button>                                <button 
                                    wire:click="confirmDelete({{ $office->OfficeID }}, 'office')"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">delete</span>
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="p-8 text-center text-gray-500">
                        <div class="flex flex-col items-center">
                            <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">business</span>
                            <p>No offices found.</p>
                        </div>
                    </div>
                @endforelse
            </div>

            <!-- Desktop Table View (Offices) -->
            <div class="hidden sm:block overflow-x-auto p-3">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Office Name</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Type</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden md:table-cell">Location</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden lg:table-cell">Head</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden sm:table-cell">Staff Count</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($offices as $office)
                            <tr class="hover:bg-gray-50">
                                <td class="p-4">
                                    <div class="font-medium text-gray-700">{{ $office->OfficeName }}</div>
                                    @if($office->ContactInfo)
                                        <div class="text-sm text-gray-500">{{ $office->ContactInfo }}</div>
                                    @endif
                                </td>
                                <td class="p-4">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $office->OfficeType === 'Regional Office' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800' }}">
                                        {{ $office->OfficeType }}
                                    </span>
                                </td>
                                <td class="p-4 text-sm text-gray-700 hidden md:table-cell">
                                    {{ $office->Location ?? 'Not specified' }}
                                </td>
                                <td class="p-4 text-sm text-gray-700 hidden lg:table-cell">
                                    {{ $office->HeadName ?? 'Not assigned' }}
                                </td>
                                <td class="p-4 text-sm text-gray-700 hidden sm:table-cell">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                        {{ $office->staff->count() }} staff
                                    </span>
                                </td>
                                <td class="p-4">
                                    <div class="flex items-center space-x-2">
                                        <button 
                                            wire:click="editOffice({{ $office->OfficeID }})"
                                            class="inline-flex items-center px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">edit</span>
                                            Edit
                                        </button>
                                        <button                                            wire:click="confirmDelete({{ $office->OfficeID }}, 'office')"
                                            class="inline-flex items-center px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">delete</span>
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="p-8 text-center text-gray-500">
                                    <div class="flex flex-col items-center">
                                        <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">business</span>
                                        <p>No offices found. Add your first office to get started.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
              <!-- Pagination -->
            @if($offices->hasPages())
                <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="text-sm text-gray-700">
                            Showing {{ $offices->firstItem() }} to {{ $offices->lastItem() }} of {{ $offices->total() }} offices
                        </div>
                        <div class="flex items-center space-x-1">
                            @if($offices->onFirstPage())
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @else
                                <button wire:click="previousPage('offices-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @endif
                            @foreach($offices->getUrlRange(1, $offices->lastPage()) as $page => $url)
                                @if($page == $offices->currentPage())
                                    <button class="px-3 py-1.5 text-sm bg-green-600 text-white rounded-md hover:bg-green-700">{{ $page }}</button>
                                @else
                                    <button wire:click="gotoPage({{ $page }}, 'offices-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">{{ $page }}</button>
                                @endif
                            @endforeach
                            @if($offices->hasMorePages())
                                <button wire:click="nextPage('offices-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @else
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @endif
        </div>
    @endif

    <!-- Users Tab -->
    @if($activeTab === 'users')
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <!-- Header with Search, Filters and Add Button -->
            <div class="p-6 border-b border-gray-200">
                <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-semibold text-gray-800">User Management</h2>
                        <p class="text-sm text-gray-600 mt-1">Manage user accounts and their roles</p>
                    </div>
                    
                    <!-- Search and Filters Row -->
                    <div class="flex flex-col sm:flex-row gap-3 lg:items-center">
                        <!-- Search Bar -->
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="material-symbols-outlined text-gray-400 text-sm">search</span>
                            </div>
                            <input type="text" 
                                   wire:model.live.debounce.300ms="search"
                                   class="block w-full sm:w-64 pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                                   placeholder="Search users...">                        </div>

                        <!-- Role Filter -->
                        <div class="min-w-[180px]">
                            <select wire:model.live="roleFilter" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                                <option value="">All Roles</option>
                                @foreach($roles as $role)
                                    <option value="{{ $role->RoleID }}">{{ $role->RoleName }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Clear Filters Button -->
                        @if($search || $roleFilter)
                            <button wire:click="clearFilters" 
                                    class="px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                <span class="material-symbols-outlined text-sm">clear</span>
                            </button>
                        @endif

                        <!-- Add User Button -->
                        <button 
                            wire:click="openUserModal"
                            class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap">
                            <span class="material-symbols-outlined mr-2 text-sm">add</span>
                            Add User
                        </button>
                    </div>
                </div>
            </div>            <!-- Mobile Card View (Users) -->
            <div class="block sm:hidden">
                @forelse($users as $user)
                    <div class="border-b border-gray-200 p-6">
                        <div class="space-y-3">
                            <div class="font-medium text-gray-700">{{ $user->name }}</div>
                            <div class="text-sm text-gray-500">{{ $user->email }}</div>
                            <div class="flex items-center gap-2 flex-wrap">
                                @if($user->roles->first())
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                                        @if($user->roles->first()->RoleName === 'Focal Person') bg-purple-100 text-purple-800
                                        @elseif($user->roles->first()->RoleName === 'Provincial Office') bg-green-100 text-green-800
                                        @elseif($user->roles->first()->RoleName === 'Project Development Officer') bg-blue-100 text-blue-800
                                        @else bg-gray-100 text-gray-800
                                        @endif">
                                        {{ $user->roles->first()->RoleName }}
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">No role</span>
                                @endif
                                 <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    {{ $user->staff->count() }} staff
                                </span>
                            </div>
                            <div class="text-sm text-gray-500">Created: {{ $user->created_at->format('M d, Y') }}</div>
                            @if($user->lastActivity())
                                <div class="text-sm text-gray-500 flex items-center">
                                    <span>Last active: </span>
                                    <span class="flex items-center ml-1">
                                        <span class="h-2 w-2 mr-1 {{ $user->lastActivity()->diffInMinutes() < 15 ? 'bg-green-500' : 'bg-gray-300' }} rounded-full"></span>
                                        {{ $user->lastActivity()->diffForHumans() }}
                                    </span>
                                </div>
                            @endif
                            <div class="flex gap-2 pt-2">
                                <button 
                                    wire:click="editUser({{ $user->id }})"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">edit</span>
                                    Edit
                                </button>                                <button 
                                    wire:click="confirmDelete({{ $user->id }}, 'user')"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">delete</span>
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="p-8 text-center text-gray-500">
                        <div class="flex flex-col items-center">
                            <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">person</span>
                            <p>No users found.</p>
                        </div>
                    </div>
                @endforelse
            </div>            <!-- Users Table -->
            <div class="hidden sm:block overflow-x-auto p-3">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Name</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Email</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Role</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden sm:table-cell">Staff Count</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden md:table-cell">Created</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden lg:table-cell">Last Active</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($users as $user)
                            <tr class="hover:bg-gray-50">
                                <td class="p-4">
                                    <div class="font-medium text-gray-700">{{ $user->name }}</div>
                                </td>
                                <td class="p-4 text-sm text-gray-900">
                                    {{ $user->email }}
                                </td>
                                <td class="p-4">
                                    @if($user->roles->first())
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                            @if($user->roles->first()->RoleName === 'Focal Person') bg-purple-100 text-purple-800
                                            @elseif($user->roles->first()->RoleName === 'Provincial Office') bg-green-100 text-green-800
                                            @elseif($user->roles->first()->RoleName === 'Project Development Officer') bg-blue-100 text-blue-800
                                            @else bg-gray-100 text-gray-800
                                            @endif">
                                            {{ $user->roles->first()->RoleName }}
                                        </span>
                                    @else
                                        <span class="text-gray-400">No role assigned</span>
                                    @endif
                                </td>
                                <td class="p-4 text-sm text-gray-700 hidden sm:table-cell">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                        {{ $user->staff->count() }} staff
                                    </span>
                                </td>                                <td class="p-4 text-sm text-gray-500 hidden md:table-cell">
                                    {{ $user->created_at->format('M d, Y') }}
                                </td>
                                <td class="p-4 text-sm text-gray-500 hidden lg:table-cell">
                                    @if($user->lastActivity())
                                        <span class="flex items-center">
                                            <span class="h-2 w-2 mr-2 {{ $user->lastActivity()->diffInMinutes() < 15 ? 'bg-green-500' : 'bg-gray-300' }} rounded-full"></span>
                                            {{ $user->lastActivity()->diffForHumans() }}
                                        </span>
                                    @else
                                        <span class="text-gray-400">Offline</span>
                                    @endif
                                </td>
                                <td class="p-4">
                                    <div class="flex items-center space-x-2">
                                        <button 
                                            wire:click="editUser({{ $user->id }})"
                                            class="inline-flex items-center px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">edit</span>
                                            Edit
                                        </button>
                                        <button                                            wire:click="confirmDelete({{ $user->id }}, 'user')"
                                            class="inline-flex items-center px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">delete</span>
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="p-8 text-center text-gray-500">
                                    <div class="flex flex-col items-center">
                                        <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">person</span>
                                        <p>No users found. Add your first user to get started.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>            <!-- Pagination -->
            @if($users->hasPages())
                <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="text-sm text-gray-700">
                            Showing {{ $users->firstItem() }} to {{ $users->lastItem() }} of {{ $users->total() }} users
                        </div>
                        <div class="flex items-center space-x-1">
                            @if($users->onFirstPage())
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @else
                                <button wire:click="previousPage('users-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @endif
                            
                            @foreach($users->getUrlRange(1, $users->lastPage()) as $page => $url)
                                @if($page == $users->currentPage())
                                    <button class="px-3 py-1.5 text-sm bg-green-600 text-white rounded-md hover:bg-green-700">{{ $page }}</button>
                                @else
                                    <button wire:click="gotoPage({{ $page }}, 'users-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">{{ $page }}</button>
                                @endif
                            @endforeach
                            
                            @if($users->hasMorePages())
                                <button wire:click="nextPage('users-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @else
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @endif
        </div>
    @endif

    <!-- Staff Tab -->
    @if($activeTab === 'staff')
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <!-- Header with Search, Filters and Add Button -->
            <div class="p-6 border-b border-gray-200">
                <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-semibold text-gray-800">Staff Management</h2>
                        <p class="text-sm text-gray-600 mt-1">Manage staff members and their office assignments</p>
                    </div>
                    
                    <!-- Search and Filters Row -->
                    <div class="flex flex-col sm:flex-row gap-3 lg:items-center">
                        <!-- Search Bar -->
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="material-symbols-outlined text-gray-400 text-sm">search</span>
                            </div>
                            <input type="text" 
                                   wire:model.live.debounce.300ms="search"
                                   class="block w-full sm:w-64 pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                                   placeholder="Search staff...">
                        </div>                        <!-- Office Filter -->
                        <div class="min-w-[220px]">
                            <select wire:model.live="officeFilter" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                                <option value="">All Offices</option>
                                @foreach($allOffices as $office)
                                    <option value="{{ $office->OfficeID }}">{{ $office->OfficeName }}</option>
                                @endforeach
                            </select>                        </div>

                        <!-- Role Filter -->
                        <div class="min-w-[180px]">
                            <select wire:model.live="roleFilter" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                                <option value="">All Roles</option>
                                @foreach($roles as $role)
                                    <option value="{{ $role->RoleID }}">{{ $role->RoleName }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Clear Filters Button -->
                        @if($search || $officeFilter || $roleFilter)
                            <button wire:click="clearFilters" 
                                    class="px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                <span class="material-symbols-outlined text-sm">clear</span>
                            </button>
                        @endif

                        <!-- Add Staff Button -->
                        <button 
                            wire:click="openStaffModal"
                            class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap">
                            <span class="material-symbols-outlined mr-2 text-sm">add</span>
                            Add Staff
                        </button>
                    </div>
                </div>
            </div>            <!-- Mobile Card View (Staff) -->
            <div class="block sm:hidden">
                @forelse($staff as $staffMember)
                    <div class="border-b border-gray-200 p-6">
                        <div class="space-y-3">
                            <div class="font-medium text-gray-700">{{ $staffMember->FullName }}</div>
                            @if($staffMember->Position)
                                <div class="text-sm text-gray-600"><span class="font-medium">Position:</span> {{ $staffMember->Position }}</div>
                            @endif
                            <div class="text-sm text-gray-600">
                                <span class="font-medium">Office:</span> {{ $staffMember->office->OfficeName }}
                            </div>
                            <div class="text-sm text-gray-600">
                                <span class="font-medium">User:</span> {{ $staffMember->user->name }}
                            </div>
                             @if($staffMember->ContactDetails)
                                <div class="text-sm text-gray-500">Contact: {{ $staffMember->ContactDetails }}</div>
                            @endif
                            <div class="text-sm text-gray-600">
                                <span class="font-medium">Permissions:</span>
                                <div class="flex flex-wrap gap-1 mt-1">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">View</span>
                                    @foreach($staffMember->permissions as $permission)
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                                            @if($permission->PermissionName === 'Edit') bg-yellow-100 text-yellow-800
                                            @elseif($permission->PermissionName === 'Create') bg-green-100 text-green-800
                                            @elseif($permission->PermissionName === 'Delete') bg-red-100 text-red-800
                                            @else bg-gray-100 text-gray-800
                                            @endif">
                                            {{ $permission->PermissionName }}
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                            <div class="flex gap-2 pt-2">
                                <button 
                                    wire:click="editStaff({{ $staffMember->StaffID }})"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">edit</span>
                                    Edit
                                </button>
                                <button 
                                    wire:click="openPermissionModal({{ $staffMember->StaffID }})"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-purple-100 hover:bg-purple-200 text-purple-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">security</span>
                                    Permissions
                                </button>                                <button 
                                    wire:click="confirmDelete({{ $staffMember->StaffID }}, 'staff')"
                                    class="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-medium rounded-md transition-colors">
                                    <span class="material-symbols-outlined mr-1 text-sm">delete</span>
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="p-8 text-center text-gray-500">
                        <div class="flex flex-col items-center">
                            <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">people</span>
                            <p>No staff members found.</p>
                        </div>
                    </div>
                @endforelse
            </div>            <!-- Staff Table -->
            <div class="hidden sm:block overflow-x-auto p-3">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Full Name</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden sm:table-cell">Position</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Office</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">User Account</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden md:table-cell">Contact</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($staff as $staffMember)
                            <tr class="hover:bg-gray-50">
                                <td class="p-4">
                                    <div class="font-medium text-gray-700">{{ $staffMember->FullName }}</div>
                                </td>
                                <td class="p-4 text-sm text-gray-900 hidden sm:table-cell">
                                    {{ $staffMember->Position ?? 'Not specified' }}
                                </td>
                                <td class="p-4">
                                    <div class="text-sm">
                                        <div class="font-medium text-gray-700">{{ $staffMember->office->OfficeName }}</div>
                                        <div class="text-gray-500">{{ $staffMember->office->OfficeType }}</div>
                                    </div>
                                </td>
                                <td class="p-4">
                                    <div class="text-sm">
                                        <div class="font-medium text-gray-700">{{ $staffMember->user->name }}</div>
                                        <div class="text-gray-500">{{ $staffMember->user->email }}</div>
                                    </div>
                                </td>
                                <td class="p-4 text-sm text-gray-900 hidden md:table-cell">
                                    {{ $staffMember->ContactDetails ?? 'Not provided' }}
                                </td>
                                <td class="p-4">
                                    <div class="flex items-center space-x-2">
                                        <button 
                                            wire:click="editStaff({{ $staffMember->StaffID }})"
                                            class="inline-flex items-center px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">edit</span>
                                            Edit
                                        </button>
                                        <button 
                                            wire:click="openPermissionModal({{ $staffMember->StaffID }})"
                                            class="inline-flex items-center px-3 py-1.5 bg-purple-100 hover:bg-purple-200 text-purple-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">security</span>
                                            Permissions
                                        </button>
                                        <button                                            wire:click="confirmDelete({{ $staffMember->StaffID }}, 'staff')"
                                            class="inline-flex items-center px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-medium rounded-md transition-colors">
                                            <span class="material-symbols-outlined mr-1 text-sm">delete</span>
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="p-8 text-center text-gray-500">
                                    <div class="flex flex-col items-center">
                                        <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">people</span>
                                        <p>No staff members found. Add your first staff member to get started.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>            <!-- Pagination -->
            @if($staff->hasPages())
                <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="text-sm text-gray-700">
                            Showing {{ $staff->firstItem() }} to {{ $staff->lastItem() }} of {{ $staff->total() }} staff members
                        </div>
                        <div class="flex items-center space-x-1">
                            @if($staff->onFirstPage())
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @else
                                <button wire:click="previousPage('staff-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @endif
                            
                            @foreach($staff->getUrlRange(1, $staff->lastPage()) as $page => $url)
                                @if($page == $staff->currentPage())
                                    <button class="px-3 py-1.5 text-sm bg-green-600 text-white rounded-md hover:bg-green-700">{{ $page }}</button>
                                @else
                                    <button wire:click="gotoPage({{ $page }}, 'staff-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">{{ $page }}</button>
                                @endif
                            @endforeach
                            
                            @if($staff->hasMorePages())
                                <button wire:click="nextPage('staff-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @else
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @endif
        </div>
    @endif

    <!-- Login Attempts Tab -->
    @if($activeTab === 'login-attempts')
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <!-- Header with Search, Filters -->
            <div class="p-6 border-b border-gray-200">
                <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-semibold text-gray-800">Login Attempts</h2>
                        <p class="text-sm text-gray-600 mt-1">Monitor login activities and identify potential security issues</p>
                    </div>
                    
                    <!-- Search and Filters Row -->
                    <div class="flex flex-col sm:flex-row gap-3 lg:items-center">
                        <!-- Search Bar -->
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="material-symbols-outlined text-gray-400 text-sm">search</span>
                            </div>
                            <input type="text" 
                                   wire:model.live.debounce.300ms="search"
                                   class="block w-full sm:w-64 pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                                   placeholder="Search by email or IP...">
                        </div>                        <!-- Status Filter -->
                        <div class="min-w-[180px]">
                            <select wire:model.live="loginStatusFilter" 
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                                <option value="">All Attempts</option>
                                <option value="success">Successful Only</option>
                                <option value="failed">Failed Only</option>
                            </select>
                        </div>                        <!-- User Filter -->
                        <div class="min-w-[180px]">
                            <select wire:model.live="loginUserFilter" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                                <option value="">All Emails</option>
                                <option value="existing_users">Only Existing Users</option>
                            </select>
                        </div>                        <!-- Date Filter -->
                        <div class="min-w-[150px]">
                            <input type="date"
                                   wire:model.live="loginDateFilter"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                        </div><!-- Clear Filters Button -->
                        @if($search || ($loginStatusFilter ?? false) || ($loginDateFilter ?? false) || ($loginUserFilter ?? false))
                            <button wire:click="clearLoginFilters" 
                                    class="px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                <span class="material-symbols-outlined text-sm">clear</span>
                            </button>
                        @endif
                    </div>
                </div>
            </div>            <!-- Mobile Card View (Login Attempts) -->
            <div class="block sm:hidden">
                @forelse($loginAttempts ?? [] as $attempt)
                    <div class="border-b border-gray-200 p-6">
                        <div class="space-y-3">
                            <div class="font-medium text-gray-700">{{ $attempt->email }}</div>
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium {{ $attempt->successful ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                    {{ $attempt->successful ? 'Success' : 'Failed' }}
                                </span>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    {{ $attempt->ip_address }}
                                </span>
                            </div>
                            <div class="text-sm text-gray-500">{{ $attempt->created_at->format('M d, Y H:i:s') }}</div>
                            <div class="text-xs text-gray-500 mt-1 truncate" title="{{ $attempt->user_agent }}">
                                {{ \Illuminate\Support\Str::limit($attempt->user_agent, 50) }}
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="p-8 text-center text-gray-500">
                        <div class="flex flex-col items-center">
                            <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">security</span>
                            <p>No login attempts found.</p>
                        </div>
                    </div>
                @endforelse
            </div>            <!-- Login Attempts Table -->
            <div class="hidden sm:block overflow-x-auto p-3">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Email</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">IP Address</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Status</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm">Date & Time</th>
                            <th class="text-left p-4 font-medium text-gray-800 text-sm hidden lg:table-cell">User Agent</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @forelse($loginAttempts ?? [] as $attempt)
                            <tr class="hover:bg-gray-50">
                                <td class="p-4 text-sm text-gray-900">
                                    {{ $attempt->email }}
                                </td>
                                <td class="p-4 text-sm text-gray-700">
                                    {{ $attempt->ip_address }}
                                </td>
                                <td class="p-4">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                        {{ $attempt->successful ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                        {{ $attempt->successful ? 'Success' : 'Failed' }}
                                    </span>
                                </td>
                                <td class="p-4 text-sm text-gray-700">
                                    {{ $attempt->created_at->format('M d, Y H:i:s') }}
                                </td>
                                <td class="p-4 text-xs text-gray-500 hidden lg:table-cell max-w-xs truncate">
                                    <span title="{{ $attempt->user_agent }}">
                                        {{ \Illuminate\Support\Str::limit($attempt->user_agent, 50) }}
                                    </span>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="p-8 text-center text-gray-500">
                                    <div class="flex flex-col items-center">
                                        <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">security</span>
                                        <p>No login attempts found.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>            <!-- Pagination -->
            @if(isset($loginAttempts) && $loginAttempts->hasPages())
                <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="text-sm text-gray-700">
                            Showing {{ $loginAttempts->firstItem() }} to {{ $loginAttempts->lastItem() }} of {{ $loginAttempts->total() }} login attempts
                        </div>
                        <div class="flex items-center space-x-1">
                            @if($loginAttempts->onFirstPage())
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @else
                                <button wire:click="previousPage('login-attempts-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Previous</span>
                                    <span class="material-symbols-outlined text-sm">chevron_left</span>
                                </button>
                            @endif
                            
                            @foreach($loginAttempts->getUrlRange(1, $loginAttempts->lastPage()) as $page => $url)
                                @if($page == $loginAttempts->currentPage())
                                    <button class="px-3 py-1.5 text-sm bg-green-600 text-white rounded-md hover:bg-green-700">{{ $page }}</button>
                                @else
                                    <button wire:click="gotoPage({{ $page }}, 'login-attempts-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">{{ $page }}</button>
                                @endif
                            @endforeach
                            
                            @if($loginAttempts->hasMorePages())
                                <button wire:click="nextPage('login-attempts-page')" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @else
                                <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                                    <span class="hidden sm:inline mr-1">Next</span>
                                    <span class="material-symbols-outlined text-sm">chevron_right</span>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @endif
        </div>
    @endif    <!-- Office Modal -->    @if($showOfficeModal)
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" 
             x-data 
             @office-saved.window="$wire.showOfficeModal = false" 
             @office-closed.window="$wire.showOfficeModal = false"
             @notify.window="setTimeout(() => { $wire.closeOfficeModal() }, 500)">
            <div class="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                <!-- Modal Header -->
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-900">
                            {{ $editingOffice ? 'Edit Office' : 'Add New Office' }}
                        </h3>
                        <button 
                            wire:click="closeOfficeModal"
                            class="text-gray-400 hover:text-gray-600">
                            <span class="material-symbols-outlined">close</span>
                        </button>
                    </div>
                </div>

                <!-- Modal Body -->
                <form wire:submit.prevent="saveOffice" class="p-6 space-y-4">
                    <!-- Office Name -->
                    <div>
                        <label for="officeName" class="block text-sm font-medium text-gray-700 mb-2">
                            Office Name <span class="text-red-500">*</span>
                        </label>
                        <select 
                            id="officeName"
                            wire:model="officeName"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="">Select an office</option>
                            <option value="Albay PCA Provincial Office">Albay PCA Provincial Office</option>
                            <option value="Camarines Norte PCA Provincial Office">Camarines Norte PCA Provincial Office</option>
                            <option value="Camarines Sur PCA Provincial Office">Camarines Sur PCA Provincial Office</option>
                            <option value="Sorsogon PCA Provincial Office">Sorsogon PCA Provincial Office</option>
                            <option value="Catanduanes PCA Provincial Office">Catanduanes PCA Provincial Office</option>
                            <option value="Masbate PCA Provincial Office">Masbate PCA Provincial Office</option>
                            <option value="PCA Region V Office">PCA Region V Office</option>
                        </select>
                        @error('officeName') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Office Type -->
                    <div>
                        <label for="officeType" class="block text-sm font-medium text-gray-700 mb-2">
                            Office Type <span class="text-red-500">*</span>
                        </label>
                        <select 
                            id="officeType"
                            wire:model="officeType"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="Provincial Office">Provincial Office</option>
                            <option value="Regional Office">Regional Office</option>
                        </select>
                        @error('officeType') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Location -->
                    <div>
                        <label for="location" class="block text-sm font-medium text-gray-700 mb-2">
                            Location
                        </label>
                        <input 
                            type="text" 
                            id="location"
                            wire:model="location"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Enter office location">
                        @error('location') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Contact Info -->
                    <div>
                        <label for="contactInfo" class="block text-sm font-medium text-gray-700 mb-2">
                            Contact Information
                        </label>
                        <input 
                            type="text" 
                            id="contactInfo"
                            wire:model="contactInfo"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Phone, email, etc.">
                        @error('contactInfo') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Head Name -->
                    <div> 
                        <label for="headName" class="block text-sm font-medium text-gray-700 mb-2">
                            Office Head
                        </label>
                        <input 
                            type="text" 
                            id="headName"
                            wire:model="headName"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Name of office head">
                        @error('headName') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Modal Footer -->
                    <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                        <button 
                            type="button"
                            wire:click="closeOfficeModal"
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                            Cancel
                        </button>
                        <button 
                            type="submit"
                            class="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg">
                            {{ $editingOffice ? 'Update Office' : 'Create Office' }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif    <!-- User Modal -->    @if($showUserModal)
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" 
             x-data 
             @user-saved.window="$wire.showUserModal = false" 
             @user-closed.window="$wire.showUserModal = false"
             @notify.window="setTimeout(() => { $wire.closeUserModal() }, 500)">
            <div class="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                <!-- Modal Header -->
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-900">
                            {{ $editingUser ? 'Edit User' : 'Add New User' }}
                        </h3>
                        <button 
                            wire:click="closeUserModal"
                            class="text-gray-400 hover:text-gray-600">
                            <span class="material-symbols-outlined">close</span>
                        </button>
                    </div>
                </div>

                <!-- Modal Body -->
                <form wire:submit.prevent="saveUser" class="p-6 space-y-4">
                    <!-- User Name -->
                    <div>
                        <label for="userName" class="block text-sm font-medium text-gray-700 mb-2">
                            Full Name <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="userName"
                            wire:model="userName"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Enter full name">
                        @error('userName') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Email -->
                    <div>
                        <label for="userEmail" class="block text-sm font-medium text-gray-700 mb-2">
                            Email Address <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="email" 
                            id="userEmail"
                            wire:model="userEmail"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Enter email address">
                        @error('userEmail') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>                    <!-- Password -->
                    <div x-data="{ showPassword: false }">
                        <label for="userPassword" class="block text-sm font-medium text-gray-700 mb-2">
                            Password 
                            @if($editingUser)
                                <span class="text-gray-500">(leave blank to keep current password)</span>
                            @else
                                <span class="text-red-500">*</span>
                            @endif
                        </label>                        <div class="relative">
                            <input 
                                :type="showPassword ? 'text' : 'password'" 
                                id="userPassword"
                                wire:model="userPassword"
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                                placeholder="Enter password">
                            <button 
                                type="button" 
                                @click="showPassword = !showPassword" 
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 focus:outline-none">
                                <svg x-show="showPassword" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                                    <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd" />
                                </svg>
                                <svg x-show="!showPassword" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd" />
                                    <path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.065 7 9.542 7 .847 0 1.669-.105 2.454-.303z" />
                                </svg>
                            </button>
                        </div>
                        <p class="mt-1 text-xs text-gray-500">Must contain at least 8 characters, including uppercase, lowercase, number, and special character (@$!%*?&).</p>
                        @error('userPassword') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Role -->
                    <div>
                        <label for="userRole" class="block text-sm font-medium text-gray-700 mb-2">
                            Role <span class="text-red-500">*</span>
                        </label>
                        <select 
                            id="userRole"
                            wire:model="userRole"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="">Select a role</option>
                            @foreach($roles as $role)
                                <option value="{{ $role->RoleID }}">{{ $role->RoleName }}</option>
                            @endforeach
                        </select>
                        @error('userRole') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Modal Footer -->
                    <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                        <button 
                            type="button"
                            wire:click="closeUserModal"
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                            Cancel
                        </button>
                        <button 
                            type="submit"
                            class="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg">
                            {{ $editingUser ? 'Update User' : 'Create User' }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif

    <!-- Staff Modal -->    @if($showStaffModal)
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
             x-data 
             @staff-saved.window="$wire.showStaffModal = false"
             @staff-closed.window="$wire.showStaffModal = false"
             @staff-error.window="$wire.showStaffModal = false"
             @notify.window="setTimeout(() => { $wire.closeStaffModal() }, 500)">
            <div class="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                <!-- Modal Header -->
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-900">
                            {{ $editingStaff ? 'Edit Staff' : 'Add New Staff' }}
                        </h3>
                        <button 
                            wire:click="closeStaffModal"
                            class="text-gray-400 hover:text-gray-600">
                            <span class="material-symbols-outlined">close</span>
                        </button>
                    </div>
                </div>

                <!-- Modal Body -->
                <form wire:submit.prevent="saveStaff" class="p-6 space-y-4">
                    <!-- Full Name -->
                    <div>
                        <label for="staffFullName" class="block text-sm font-medium text-gray-700 mb-2">
                            Full Name <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="staffFullName"
                            wire:model="staffFullName"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Enter full name">
                        @error('staffFullName') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Position -->
                    <div>
                        <label for="staffPosition" class="block text-sm font-medium text-gray-700 mb-2">
                            Position
                        </label>
                        <input 
                            type="text" 
                            id="staffPosition"
                            wire:model="staffPosition"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Enter position">
                        @error('staffPosition') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Contact Details -->
                    <div>
                        <label for="staffContactDetails" class="block text-sm font-medium text-gray-700 mb-2">
                            Contact Details
                        </label>
                        <input 
                            type="text" 
                            id="staffContactDetails"
                            wire:model="staffContactDetails"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder="Phone, email, etc.">
                        @error('staffContactDetails') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Office -->
                    <div>
                        <label for="staffOfficeId" class="block text-sm font-medium text-gray-700 mb-2">
                            Office <span class="text-red-500">*</span>
                        </label>                        <select 
                            id="staffOfficeId"
                            wire:model="staffOfficeId"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="">Select an office</option>
                            @foreach($allOffices as $office)
                                <option value="{{ $office->OfficeID }}">{{ $office->OfficeName }}</option>
                            @endforeach
                        </select>
                        @error('staffOfficeId') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- User Account -->
                    <div>
                        <label for="staffUserId" class="block text-sm font-medium text-gray-700 mb-2">
                            User Account <span class="text-red-500">*</span>
                        </label>
                        <select 
                            id="staffUserId"
                            wire:model="staffUserId"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="">Select a user</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}">
                                    {{ $user->name }} ({{ $user->roles->first()?->RoleName ?? 'No role' }})
                                </option>
                            @endforeach
                        </select>
                        @error('staffUserId') 
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Modal Footer -->
                    <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                        <button 
                            type="button"
                            wire:click="closeStaffModal"
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                            Cancel
                        </button>
                        <button 
                            type="submit"
                            class="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg">
                            {{ $editingStaff ? 'Update Staff' : 'Create Staff' }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif

    <!-- Permission Modal -->    @if($showPermissionModal)
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
             x-data 
             @permissions-saved.window="$wire.showPermissionModal = false"
             @permissions-closed.window="$wire.showPermissionModal = false"
             @notify.window="setTimeout(() => { $wire.closePermissionModal() }, 500)">
            <div class="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                <!-- Modal Header -->
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-900">
                            Manage Permissions for {{ $managingPermissionsStaff?->FullName }}
                        </h3>
                        <button 
                            wire:click="closePermissionModal"
                            class="text-gray-400 hover:text-gray-600">
                            <span class="material-symbols-outlined">close</span>
                        </button>
                    </div>
                </div>

                <!-- Modal Body -->
                <form wire:submit.prevent="savePermissions" class="p-6 space-y-4">
                    <div class="space-y-3">
                        <p class="text-sm text-gray-600 mb-4">
                            Select the permissions you want to grant to this staff member. Note that <strong>View permission</strong> is automatically granted to all staff members.
                        </p>
                        
                        <!-- View Permission (Always Granted) -->
                        <div class="flex items-center p-3 bg-blue-50 rounded-lg">
                            <div class="flex items-center">
                                <input 
                                    type="checkbox" 
                                    checked 
                                    disabled
                                    class="h-4 w-4 text-blue-600 border-gray-300 rounded opacity-50">
                                <label class="ml-3 text-sm font-medium text-blue-700">
                                    View
                                </label>
                            </div>
                            <span class="ml-auto text-xs text-blue-600">Always granted</span>
                        </div>

                        <!-- Other Permissions -->
                        @if(isset($permissions) && $permissions)
                            @foreach($permissions as $permission)
                                @if($permission->PermissionName !== 'View')
                                    <div class="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                                        <div class="flex items-center">
                                            <input 
                                                type="checkbox" 
                                                id="permission_{{ $permission->PermissionID }}"
                                                value="{{ $permission->PermissionID }}"
                                                wire:model="selectedPermissions"
                                                class="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500">
                                            <label for="permission_{{ $permission->PermissionID }}" class="ml-3 text-sm font-medium text-gray-700">
                                                {{ $permission->PermissionName }}
                                            </label>
                                        </div>
                                        <span class="ml-auto text-xs text-gray-500">
                                            @if($permission->PermissionName === 'Edit')
                                                Can modify existing records
                                            @elseif($permission->PermissionName === 'Create')
                                                Can create new records
                                            @elseif($permission->PermissionName === 'Delete')
                                                Can delete records
                                            @endif
                                        </span>
                                    </div>
                                @endif
                            @endforeach
                        @else
                            <div class="p-3 text-center text-gray-500">
                                <p>No permissions available to assign.</p>
                            </div>
                        @endif
                    </div>

                    <!-- Modal Footer -->
                    <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                        <button 
                            type="button"
                            wire:click="closePermissionModal"
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                            Cancel
                        </button>
                        <button 
                            type="submit"
                            class="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg">
                            Save Permissions
                        </button>
                    </div>
                </form>
            </div>
        </div>    @endif    <!-- Delete Confirmation Modal -->
    @if($showDeleteConfirmModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center overflow-auto bg-black bg-opacity-50">
            <div class="relative w-full max-w-md bg-white rounded-lg shadow-lg mx-4"
                 x-data="{ }"
                 @click.outside="$wire.closeDeleteConfirmModal()"
                 @keydown.escape.window="$wire.closeDeleteConfirmModal()"
                 @notify.window="setTimeout(() => { $wire.closeDeleteConfirmModal() }, 300)"
                 @office-deleted.window="$wire.$refresh()"
                 @user-deleted.window="$wire.$refresh()"
                 @staff-deleted.window="$wire.$refresh()">
                <div class="p-6">
                    <!-- Modal Header -->
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-medium text-gray-900">Confirm Delete</h3>
                        <button 
                            type="button"
                            wire:click="closeDeleteConfirmModal"
                            class="text-gray-400 hover:text-gray-500">
                            <span class="material-symbols-outlined">close</span>
                        </button>
                    </div>
                    
                    <!-- Modal Body -->
                    <div class="mb-6">
                        <div class="p-4 mb-4 bg-amber-50 border-l-4 border-amber-400 text-amber-700">
                            <div class="flex items-center">
                                <span class="material-symbols-outlined mr-2">warning</span>
                                <p>Are you sure you want to delete this {{ $deletingItemType }}?</p>
                            </div>
                            <p class="mt-2 text-sm">This action cannot be undone.</p>
                        </div>
                    </div>
                    
                    <!-- Modal Footer -->
                    <div class="flex items-center justify-end space-x-3">                        <button 
                            type="button"
                            wire:click="closeDeleteConfirmModal"
                            wire:loading.attr="disabled"
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed">
                            Cancel
                        </button><button 
                            type="button"
                            wire:click="executeDelete"
                            wire:loading.attr="disabled"
                            class="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed">
                            <span wire:loading.remove wire:target="executeDelete">Delete</span>
                            <span wire:loading wire:target="executeDelete" class="inline-flex items-center">
                                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Deleting...
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
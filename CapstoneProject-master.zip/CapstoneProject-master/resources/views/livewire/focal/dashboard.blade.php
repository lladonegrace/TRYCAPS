<div class="p-6">
    <!-- Header Section -->
    

    <div class="bg-gradient-to-r from-green-500/85 to-green-300/80 rounded-lg p-5 mb-6 text-white shadow-lg flex items-center justify-between"> 
        <div>
            <h1 class="text-xl sm:text-2xl font-bold mb-2">
                Focal Person Dashboard 👋
            </h1>
            <p class="text-white/90">Oversee all provincial operations and performance</p>
        </div>
        <div class="flex items-center space-x-3 ml-4">
            <img src="{{ asset('images/pca-logo.svg') }}" 
                 alt="PCA Logo" 
                 class="h-24 w-auto object-contain transition-transform hover:scale-105 filter drop-shadow-[0_0_4px_rgba(255,255,255,1)]">
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- All Applications -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">All Applications</p>
                    <p class="text-3xl font-bold text-blue-600">247</p>
                </div>
                <div class="p-3 bg-blue-100 rounded-lg">
                    <span class="material-symbols-outlined text-blue-600 text-2xl">apps</span>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                <span class="text-green-600 font-medium">+12</span>
                <span class="text-gray-600 ml-1">from last month</span>
            </div>
        </div>

        <!-- Incoming Applications -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Incoming</p>
                    <p class="text-3xl font-bold text-orange-600">23</p>
                </div>
                <div class="p-3 bg-orange-100 rounded-lg">
                    <span class="material-symbols-outlined text-orange-600 text-2xl">inbox</span>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                <span class="text-blue-600 font-medium">+5</span>
                <span class="text-gray-600 ml-1">today</span>
            </div>
        </div>

        <!-- Assigned Applications -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Assigned</p>
                    <p class="text-3xl font-bold text-purple-600">89</p>
                </div>
                <div class="p-3 bg-purple-100 rounded-lg">
                    <span class="material-symbols-outlined text-purple-600 text-2xl">assignment_ind</span>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                <span class="text-green-600 font-medium">+8</span>
                <span class="text-gray-600 ml-1">this week</span>
            </div>
        </div>

        <!-- Monitoring -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Monitoring</p>
                    <p class="text-3xl font-bold text-teal-600">45</p>
                </div>
                <div class="p-3 bg-teal-100 rounded-lg">
                    <span class="material-symbols-outlined text-teal-600 text-2xl">monitoring</span>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                <span class="text-yellow-600 font-medium">3</span>
                <span class="text-gray-600 ml-1">need attention</span>
            </div>
        </div>
    </div>

    <!-- Recent Activity & Quick Actions -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Applications -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-semibold text-gray-900">Recent Applications</h2>
                <a href="{{ route('dashboard.all-applications') }}" wire:navigate class="text-blue-600 text-sm font-medium hover:text-blue-700">View All</a>
            </div>
            <div class="space-y-4">
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <span class="material-symbols-outlined text-blue-600">description</span>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">APP-2024-001</p>
                            <p class="text-sm text-gray-600">Provincial Cooperative</p>
                        </div>
                    </div>
                    <span class="px-3 py-1 bg-orange-100 text-orange-700 text-xs font-medium rounded-full">Incoming</span>
                </div>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <span class="material-symbols-outlined text-green-600">check_circle</span>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">APP-2024-002</p>
                            <p class="text-sm text-gray-600">Regional Coop Network</p>
                        </div>
                    </div>
                    <span class="px-3 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">Received</span>
                </div>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                            <span class="material-symbols-outlined text-purple-600">assignment</span>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">APP-2024-003</p>
                            <p class="text-sm text-gray-600">Local Business Coop</p>
                        </div>
                    </div>
                    <span class="px-3 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded-full">Assigned</span>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
            <div class="grid grid-cols-2 gap-4">
                <a href="{{ route('dashboard.incoming-applications') }}" wire:navigate class="flex flex-col items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                    <span class="material-symbols-outlined text-blue-600 text-3xl mb-2">inbox</span>
                    <span class="text-sm font-medium text-blue-700">View Incoming</span>
                </a>
                <a href="{{ route('dashboard.assigned-application') }}" wire:navigate class="flex flex-col items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                    <span class="material-symbols-outlined text-purple-600 text-3xl mb-2">assignment_ind</span>
                    <span class="text-sm font-medium text-purple-700">Assign Tasks</span>
                </a>
                <a href="{{ route('dashboard.progress-monitoring') }}" wire:navigate class="flex flex-col items-center p-4 bg-teal-50 rounded-lg hover:bg-teal-100 transition-colors">
                    <span class="material-symbols-outlined text-teal-600 text-3xl mb-2">monitoring</span>
                    <span class="text-sm font-medium text-teal-700">Monitor Progress</span>
                </a>
                <a href="{{ route('dashboard.manage-users') }}" wire:navigate class="flex flex-col items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <span class="material-symbols-outlined text-gray-600 text-3xl mb-2">manage_accounts</span>
                    <span class="text-sm font-medium text-gray-700">Manage Users</span>
                </a>
            </div>
        </div>
    </div>
</div> 
<div class="p-6">
    <!-- Header Section -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900 mb-2">Received Application</h1>
        <p class="text-gray-600">Manage applications that have been received and are ready for assignment</p>
    </div>

    <!-- Coming Soon Content -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
        <div class="w-24 h-24 mx-auto mb-6 bg-green-100 rounded-full flex items-center justify-center">
            <span class="material-symbols-outlined text-green-600 text-4xl">mark_email_read</span>
        </div>
        <h2 class="text-2xl font-bold text-gray-900 mb-4">Received Application</h2>
        <p class="text-gray-600 mb-6 max-w-md mx-auto">
            This section will display applications that have been received and are ready for assignment to staff members.
        </p>
        <div class="inline-flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-lg">
            <span class="material-symbols-outlined mr-2">construction</span>
            Coming Soon
        </div>
    </div>
</div>
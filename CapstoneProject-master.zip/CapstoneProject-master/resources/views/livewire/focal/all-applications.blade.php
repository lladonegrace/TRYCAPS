<div class="p-6">
    <!-- Header Section -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-700 mb-1">All Applications</h1>
        <p class="text-gray-600">Comprehensive view of all applications in the system</p>
    </div>

    <!-- Filters and Search -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <!-- Search -->
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-2">Search Applications</label>
                <div class="relative">
                    <input type="text" placeholder="Search by ID, name, or cooperative..." 
                           class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <span class="material-symbols-outlined absolute left-3 top-2.5 text-gray-400">search</span>
                </div>
            </div>
            
            <!-- Status Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="">All Status</option>
                    <option value="incoming">Incoming</option>
                    <option value="received">Received</option>
                    <option value="assigned">Assigned</option>
                    <option value="monitoring">Monitoring</option>
                    <option value="completed">Completed</option>
                </select>
            </div>

            <!-- Date Range -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
                <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="">All Time</option>
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month">This Month</option>
                    <option value="year">This Year</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Applications Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <!-- Table Header -->
        <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-semibold text-gray-900">Applications List</h2>
                <div class="flex items-center space-x-2">
                    <span class="text-sm text-gray-600">247 total applications</span>
                    <button class="p-2 text-gray-400 hover:text-gray-600">
                        <span class="material-symbols-outlined">refresh</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 border-b border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Application</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cooperative</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned To</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <!-- Sample Row 1 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <span class="material-symbols-outlined text-blue-600">description</span>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">APP-2024-001</div>
                                    <div class="text-sm text-gray-500">Cooperative Registration</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">Albay Provincial Cooperative</div>
                            <div class="text-sm text-gray-500">Reg: CO-2024-001</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-orange-100 text-orange-800">
                                Incoming
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            Not Assigned
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            Dec 20, 2024
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">High</span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex items-center space-x-2">
                                <button class="text-blue-600 hover:text-blue-900">
                                    <span class="material-symbols-outlined text-sm">visibility</span>
                                </button>
                                <button class="text-green-600 hover:text-green-900">
                                    <span class="material-symbols-outlined text-sm">assignment_ind</span>
                                </button>
                                <button class="text-gray-600 hover:text-gray-900">
                                    <span class="material-symbols-outlined text-sm">more_vert</span>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Sample Row 2 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                                    <span class="material-symbols-outlined text-green-600">description</span>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">APP-2024-002</div>
                                    <div class="text-sm text-gray-500">Project Proposal</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">Regional Coop Network</div>
                            <div class="text-sm text-gray-500">Reg: CO-2024-002</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Received
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            John Doe
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            Dec 19, 2024
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">Medium</span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex items-center space-x-2">
                                <button class="text-blue-600 hover:text-blue-900">
                                    <span class="material-symbols-outlined text-sm">visibility</span>
                                </button>
                                <button class="text-purple-600 hover:text-purple-900">
                                    <span class="material-symbols-outlined text-sm">monitoring</span>
                                </button>
                                <button class="text-gray-600 hover:text-gray-900">
                                    <span class="material-symbols-outlined text-sm">more_vert</span>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Sample Row 3 -->
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <span class="material-symbols-outlined text-purple-600">description</span>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">APP-2024-003</div>
                                    <div class="text-sm text-gray-500">Funding Request</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">Local Business Coop</div>
                            <div class="text-sm text-gray-500">Reg: CO-2024-003</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                                Assigned
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            Jane Smith
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            Dec 18, 2024
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">Low</span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex items-center space-x-2">
                                <button class="text-blue-600 hover:text-blue-900">
                                    <span class="material-symbols-outlined text-sm">visibility</span>
                                </button>
                                <button class="text-teal-600 hover:text-teal-900">
                                    <span class="material-symbols-outlined text-sm">monitoring</span>
                                </button>
                                <button class="text-gray-600 hover:text-gray-900">
                                    <span class="material-symbols-outlined text-sm">more_vert</span>
                                </button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>        <!-- Pagination -->
        <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div class="text-sm text-gray-700">
                    Showing <span class="font-medium">1</span> to <span class="font-medium">10</span> of <span class="font-medium">247</span> results
                </div>
                <div class="flex items-center space-x-1">
                    <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                        <span class="hidden sm:inline mr-1">Previous</span>
                        <span class="material-symbols-outlined text-sm">chevron_left</span>
                    </button>
                    <button class="px-3 py-1.5 text-sm bg-green-600 text-white rounded-md hover:bg-green-700">1</button>
                    <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">2</button>
                    <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">3</button>
                    <span class="px-2 py-1.5 text-sm text-gray-500">...</span>
                    <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">24</button>
                    <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                        <span class="hidden sm:inline mr-1">Next</span>
                        <span class="material-symbols-outlined text-sm">chevron_right</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div> 
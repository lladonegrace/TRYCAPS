<div>
    @if($currentComponent)
        @if(view()->exists("livewire.{$currentComponent}"))
            @php
                $componentKey = $currentComponent;
                if (isset($componentParams['id'])) {
                    $componentKey .= '-' . $componentParams['id'];
                }
            @endphp
            @livewire($currentComponent, $componentParams, key($componentKey))
        @else
            <div class="p-6 bg-red-50 border border-red-200 rounded-lg">
                <h3 class="text-red-800 font-semibold mb-2">Component Not Found</h3>
                <p class="text-red-700 mb-2">Component view not found: <code>livewire.{{ $currentComponent }}</code></p>
                <p class="text-red-600 text-sm">The requested component view file does not exist.</p>
                <div class="mt-4">
                    <button wire:click="navigateTo('{{ $this->getDefaultComponent() }}')" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                        Return to Dashboard
                    </button>
                </div>
            </div>
        @endif
    @else
        <div class="p-6 text-center">
            <p class="text-gray-500">No component selected</p>
        </div>
    @endif
</div> 
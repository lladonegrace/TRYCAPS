<div class="p-6">
    <!-- Header Section -->
     <div class="bg-gradient-to-r from-green-500/85 to-green-300/80 rounded-lg p-5 mb-6 text-white shadow-lg flex items-center justify-between"> 
        <div>
            <h1 class="text-xl sm:text-2xl font-bold mb-2">
                Project Development Officer Dashboard 👋
            </h1>
            <p class="text-white/90">Monitor project applications and development progress</p>
        </div>
        <div class="flex items-center space-x-3 ml-4">
            <img src="{{ asset('images/pca-logo.svg') }}" 
                 alt="PCA Logo" 
                 class="h-24 w-auto object-contain transition-transform hover:scale-105 filter drop-shadow-[0_0_4px_rgba(255,255,255,1)]">
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- For Review -->
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-sm p-6 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-blue-100 text-sm font-medium">For Review</p>
                    <p class="text-2xl font-bold">24</p>
                    <p class="text-blue-100 text-xs mt-1">Applications pending</p>
                </div>
                <div class="bg-blue-400 bg-opacity-30 rounded-lg p-3">
                    <span class="material-symbols-outlined text-2xl">rate_review</span>
                </div>
            </div>
        </div>

        <!-- Under Review -->
        <div class="bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl shadow-sm p-6 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-amber-100 text-sm font-medium">Under Review</p>
                    <p class="text-2xl font-bold">8</p>
                    <p class="text-amber-100 text-xs mt-1">Currently reviewing</p>
                </div>
                <div class="bg-amber-400 bg-opacity-30 rounded-lg p-3">
                    <span class="material-symbols-outlined text-2xl">pending</span>
                </div>
            </div>
        </div>

        <!-- Approved Applications -->
        <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-sm p-6 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-green-100 text-sm font-medium">Approved</p>
                    <p class="text-2xl font-bold">156</p>
                    <p class="text-green-100 text-xs mt-1">Total approved</p>
                </div>
                <div class="bg-green-400 bg-opacity-30 rounded-lg p-3">
                    <span class="material-symbols-outlined text-2xl">check_circle</span>
                </div>
            </div>
        </div>

        <!-- Progress Monitoring -->
        <div class="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl shadow-sm p-6 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-indigo-100 text-sm font-medium">Monitoring</p>
                    <p class="text-2xl font-bold">42</p>
                    <p class="text-indigo-100 text-xs mt-1">Projects tracked</p>
                </div>
                <div class="bg-indigo-400 bg-opacity-30 rounded-lg p-3">
                    <span class="material-symbols-outlined text-2xl">monitoring</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity and Quick Actions -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Recent Applications -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-800">Recent Applications</h3>
                    <span class="material-symbols-outlined text-gray-400">description</span>
                </div>
            </div>
            <div class="p-6">
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div>
                            <p class="font-medium text-gray-800">Coconut Processing Facility</p>
                            <p class="text-sm text-gray-600">Albay Farmers Cooperative</p>
                        </div>
                        <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">For Review</span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                        <div>
                            <p class="font-medium text-gray-800">Irrigation Project</p>
                            <p class="text-sm text-gray-600">Camarines Sur Coop</p>
                        </div>
                        <span class="px-2 py-1 bg-amber-100 text-amber-800 text-xs rounded-full">Under Review</span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div>
                            <p class="font-medium text-gray-800">Farm Equipment Purchase</p>
                            <p class="text-sm text-gray-600">Sorsogon Multi-Purpose Coop</p>
                        </div>
                        <span class="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Approved</span>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-gray-200">
                    <button class="text-blue-600 hover:text-blue-700 text-sm font-medium">View all applications →</button>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-800">Quick Actions</h3>
                    <span class="material-symbols-outlined text-gray-400">bolt</span>
                </div>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 gap-4">
                    <button class="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-blue-50 hover:border-blue-200 transition-colors group">
                        <div class="bg-blue-100 group-hover:bg-blue-200 rounded-lg p-2 mr-4">
                            <span class="material-symbols-outlined text-blue-600">rate_review</span>
                        </div>
                        <div class="text-left">
                            <p class="font-medium text-gray-800">Review Applications</p>
                            <p class="text-sm text-gray-600">Process pending applications</p>
                        </div>
                    </button>
                    
                    <button class="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-amber-50 hover:border-amber-200 transition-colors group">
                        <div class="bg-amber-100 group-hover:bg-amber-200 rounded-lg p-2 mr-4">
                            <span class="material-symbols-outlined text-amber-600">pending</span>
                        </div>
                        <div class="text-left">
                            <p class="font-medium text-gray-800">Under Review</p>
                            <p class="text-sm text-gray-600">Continue reviewing applications</p>
                        </div>
                    </button>
                    
                    <button class="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-indigo-50 hover:border-indigo-200 transition-colors group">
                        <div class="bg-indigo-100 group-hover:bg-indigo-200 rounded-lg p-2 mr-4">
                            <span class="material-symbols-outlined text-indigo-600">monitoring</span>
                        </div>
                        <div class="text-left">
                            <p class="font-medium text-gray-800">Monitor Progress</p>
                            <p class="text-sm text-gray-600">Track project development</p>
                        </div>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Performance Charts -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Monthly Applications Chart -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Monthly Applications</h3>
                <p class="text-sm text-gray-600">Application trends over time</p>
            </div>
            <div class="p-6">
                <div class="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                    <div class="text-center">
                        <span class="material-symbols-outlined text-4xl text-gray-300 mb-2">bar_chart</span>
                        <p class="text-gray-500">Chart placeholder</p>
                        <p class="text-sm text-gray-400">Application statistics</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Review Status Distribution -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Review Status</h3>
                <p class="text-sm text-gray-600">Current application status distribution</p>
            </div>
            <div class="p-6">
                <div class="space-y-3">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <div class="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                            <span class="text-sm text-gray-700">For Review</span>
                        </div>
                        <span class="text-sm font-medium text-gray-900">24 (45%)</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <div class="w-3 h-3 bg-amber-500 rounded-full mr-3"></div>
                            <span class="text-sm text-gray-700">Under Review</span>
                        </div>
                        <span class="text-sm font-medium text-gray-900">8 (15%)</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                            <span class="text-sm text-gray-700">Approved</span>
                        </div>
                        <span class="text-sm font-medium text-gray-900">156 (75%)</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <div class="w-3 h-3 bg-indigo-500 rounded-full mr-3"></div>
                            <span class="text-sm text-gray-700">Monitoring</span>
                        </div>
                        <span class="text-sm font-medium text-gray-900">42 (27%)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
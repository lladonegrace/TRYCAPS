<div class="p-6">
    <h1 class="text-2xl font-bold text-gray-700 mb-1">Applications Under Review</h1>
    <p class="text-gray-600">Track applications currently being reviewed</p>

    <div class="mt-8 bg-white rounded-xl shadow-sm border border-gray-200">
        <div class="p-6">
            <p class="text-gray-500">Applications under review will appear here.</p>
        </div>
    </div>
</div> 
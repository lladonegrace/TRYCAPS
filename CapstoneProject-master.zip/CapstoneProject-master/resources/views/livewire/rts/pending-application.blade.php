<div class="p-6">
    <!-- Header Section -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-700 mb-1">Pending Applications</h1>
        <p class="text-gray-600">Applications ready for certificate generation</p>
    </div>

    <!-- Content Placeholder -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div class="text-center">
            <span class="material-symbols-outlined text-6xl text-yellow-300 mb-4 block">schedule</span>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Certificate Generation Queue</h3>
            <p class="text-gray-500 mb-4">This section will show applications ready for certificate generation.</p>
            <div class="text-sm text-gray-400">
                Features to be implemented:
                <ul class="mt-2 text-left max-w-md mx-auto space-y-1">
                    <li>• Priority queue management</li>
                    <li>• PDF certificate generation</li>
                    <li>• Member certificate templates</li>
                    <li>• Batch generation tools</li>
                    <li>• Download and distribution system</li>
                </ul>
            </div>
        </div>
    </div>
</div> 
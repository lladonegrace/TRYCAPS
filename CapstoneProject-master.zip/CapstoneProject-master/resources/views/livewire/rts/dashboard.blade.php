<div class="p-6">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-blue-500/85 to-blue-300/80 rounded-lg p-5 mb-6 text-white shadow-lg flex items-center justify-between"> 
        <div>
            <h1 class="text-xl sm:text-2xl font-bold mb-2">
                Regional Technical Staff Dashboard 👋
            </h1>
            <p class="text-white/90">Manage eligibility checks and certificate generation</p>
        </div>
        <div class="flex items-center space-x-3 ml-4">
            <img src="{{ asset('images/pca-logo.svg') }}" 
                 alt="PCA Logo" 
                 class="h-24 w-auto object-contain transition-transform hover:scale-105 filter drop-shadow-[0_0_4px_rgba(255,255,255,1)]">
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Applications Card -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total Applications</p>
                    <p class="text-2xl font-bold text-gray-900">156</p>
                    <p class="text-xs text-gray-500 mt-1">All submitted applications</p>
                </div>
                <div class="bg-blue-100 p-3 rounded-lg">
                    <span class="material-symbols-outlined text-blue-600 text-2xl">apps</span>
                </div>
            </div>
        </div>

        <!-- For Eligibility Check Card -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">For Eligibility Check</p>
                    <p class="text-2xl font-bold text-orange-600">23</p>
                    <p class="text-xs text-gray-500 mt-1">Awaiting verification</p>
                </div>
                <div class="bg-orange-100 p-3 rounded-lg">
                    <span class="material-symbols-outlined text-orange-600 text-2xl">fact_check</span>
                </div>
            </div>
        </div>

        <!-- Pending Certificates Card -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Pending Certificates</p>
                    <p class="text-2xl font-bold text-yellow-600">12</p>
                    <p class="text-xs text-gray-500 mt-1">Ready for generation</p>
                </div>
                <div class="bg-yellow-100 p-3 rounded-lg">
                    <span class="material-symbols-outlined text-yellow-600 text-2xl">schedule</span>
                </div>
            </div>
        </div>

        <!-- Generated Certificates Card -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Generated This Month</p>
                    <p class="text-2xl font-bold text-green-600">45</p>
                    <p class="text-xs text-gray-500 mt-1">Certificates completed</p>
                </div>
                <div class="bg-green-100 p-3 rounded-lg">
                    <span class="material-symbols-outlined text-green-600 text-2xl">verified</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities and Quick Actions -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Eligibility Checks -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Recent Eligibility Checks</h3>
                <p class="text-sm text-gray-600">Latest member list verifications</p>
            </div>
            <div class="p-6">
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <p class="font-medium text-gray-900">Application #2024-001</p>
                            <p class="text-sm text-gray-600">15 members to verify</p>
                        </div>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                            Pending
                        </span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <p class="font-medium text-gray-900">Application #2024-002</p>
                            <p class="text-sm text-gray-600">22 members verified</p>
                        </div>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Completed
                        </span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <p class="font-medium text-gray-900">Application #2024-003</p>
                            <p class="text-sm text-gray-600">8 members to verify</p>
                        </div>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                            In Progress
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Quick Actions</h3>
                <p class="text-sm text-gray-600">Common RTS tasks</p>
            </div>
            <div class="p-6">
                <div class="space-y-3">
                    <button class="w-full flex items-center justify-between p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors text-left">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-blue-600 mr-3">fact_check</span>
                            <div>
                                <p class="font-medium text-blue-900">Start Eligibility Check</p>
                                <p class="text-sm text-blue-700">Verify member qualifications</p>
                            </div>
                        </div>
                        <span class="material-symbols-outlined text-blue-600">arrow_forward</span>
                    </button>

                    <button class="w-full flex items-center justify-between p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors text-left">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-green-600 mr-3">picture_as_pdf</span>
                            <div>
                                <p class="font-medium text-green-900">Generate Certificate</p>
                                <p class="text-sm text-green-700">Create member certificates</p>
                            </div>
                        </div>
                        <span class="material-symbols-outlined text-green-600">arrow_forward</span>
                    </button>

                    <button class="w-full flex items-center justify-between p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors text-left">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-purple-600 mr-3">analytics</span>
                            <div>
                                <p class="font-medium text-purple-900">View Reports</p>
                                <p class="text-sm text-purple-700">Certificate statistics</p>
                            </div>
                        </div>
                        <span class="material-symbols-outlined text-purple-600">arrow_forward</span>
                    </button>

                    <button class="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-gray-600 mr-3">search</span>
                            <div>
                                <p class="font-medium text-gray-900">Search Applications</p>
                                <p class="text-sm text-gray-700">Find specific applications</p>
                            </div>
                        </div>
                        <span class="material-symbols-outlined text-gray-600">arrow_forward</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div> 
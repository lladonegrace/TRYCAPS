<div class="p-6">
    <!-- Header Section -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-700 mb-1">Eligibility Check</h1>
        <p class="text-gray-600">
            <span class="font-medium">{{ $registeredCount ?? 0 }}/{{ $totalCount ?? 100 }}</span> Registered Coconut Farmers
            <span class="ml-6 inline-flex items-center">
                <span class="inline-block w-3 h-3 rounded-sm border border-gray-300 bg-white mr-1"></span>
                <span class="text-gray-600 text-sm">Not Eligible</span>
            </span>
            <span class="ml-4 inline-flex items-center">
                <span class="inline-block w-3 h-3 rounded-sm border border-gray-300 bg-green-100 mr-1"></span>
                <span class="text-gray-600 text-sm">Eligible</span>
            </span>
        </p>
    </div>

    <!-- Eligibility Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm">Full Name</th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm">Address</th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm">Registered</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @for ($i = 1; $i <= 10; $i++)
                        <tr class="hover:bg-gray-50">
                            <td class="p-4">
                                <div class="font-medium text-gray-700">DELA CRUZ, JUAN BONIFACIO JR.</div>
                            </td>
                            <td class="p-4">
                                <div class="text-sm text-gray-900">Buang, Tabaco City</div>
                            </td>
                            <td class="p-4">
                                <div class="flex justify-center">
                                    <input type="checkbox" class="h-5 w-5 rounded border-gray-300 text-green-600 focus:ring-green-500">
                                </div>
                            </td>
                        </tr>
                    @endfor
                </tbody>
            </table>
        </div>

        <!-- Action Buttons -->
        <div class="px-6 py-4 border-t border-gray-200 flex justify-between">
            <button wire:click="goBack" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                Back
            </button>
            <button wire:click="generateCertificate" class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                Generate Certificate
            </button>
        </div>
    </div>
</div>

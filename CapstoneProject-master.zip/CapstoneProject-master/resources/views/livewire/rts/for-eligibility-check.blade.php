<div class="p-6">    <!-- Header Section -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-700 mb-1">For Eligibility Check</h1>
        <p class="text-gray-600">Verify member qualifications and eligibility for certificate generation</p>
    </div>    <!-- Table Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200">
        <!-- Search and Filters -->
        <div class="p-6 border-b border-gray-200 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"><!-- Search Box -->
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span class="material-symbols-outlined text-gray-400 text-sm">search</span>
                </div>
                <input wire:model.live.debounce.300ms="search" type="text" 
                       class="block w-full sm:w-64 pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                       placeholder="Search applications...">
            </div><!-- Filter and Per Page -->
            <div class="flex gap-3 w-full md:w-auto">
                <!-- Province Filter -->
                <div class="min-w-[180px]">
                    <select wire:model.live="filterProvince" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm">
                        <option value="">All Provinces</option>
                        @foreach($provinces as $province)
                            <option value="{{ $province }}">{{ $province }}</option>
                        @endforeach
                    </select>
                </div>            </div>
        </div>
        
        <!-- Mobile Card View (Applications) -->
        <div class="block sm:hidden">
            @forelse($applications as $application)
                <div class="border-b border-gray-200 p-6">
                    <div class="space-y-3">
                        <div class="font-medium text-gray-700">{{ $application['reference_id'] }}</div>
                        <div class="text-sm text-gray-900">{{ $application['title'] }}</div>
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                {{ $application['status'] }}
                            </span>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                {{ $application['province'] }}
                            </span>
                        </div>
                        <div class="text-sm text-gray-600">{{ $application['applicant_name'] }}</div>
                        <div class="flex items-center space-x-2 pt-2">
                            <button wire:click="editApplication({{ $application['id'] }})" 
                                    class="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50">
                                <span class="material-symbols-outlined text-sm mr-1">edit</span>
                                Edit
                            </button>
                            <button wire:click="viewApplication({{ $application['id'] }})" 
                                    class="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50">
                                <span class="material-symbols-outlined text-sm mr-1">visibility</span>
                                View
                            </button>
                        </div>
                    </div>
                </div>
            @empty
                <div class="p-8 text-center text-gray-500">
                    <div class="flex flex-col items-center">
                        <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">description</span>
                        <p>No applications found matching your search criteria.</p>
                    </div>
                </div>
            @endforelse
        </div>
        
        <!-- Applications Table -->
        <div class="hidden sm:block overflow-x-auto p-3">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm cursor-pointer" wire:click="sortBy('reference_id')">
                            <div class="flex items-center">
                                Reference ID
                                @if($sortField === 'reference_id')
                                    <svg class="ml-1 w-4 h-4 {{ $sortDirection === 'asc' ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                    </svg>
                                @endif
                            </div>
                        </th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm cursor-pointer" wire:click="sortBy('title')">
                            <div class="flex items-center">
                                Application Title
                                @if($sortField === 'title')
                                    <svg class="ml-1 w-4 h-4 {{ $sortDirection === 'asc' ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                    </svg>
                                @endif
                            </div>
                        </th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm cursor-pointer" wire:click="sortBy('applicant_name')">
                            <div class="flex items-center">
                                Applicant Name
                                @if($sortField === 'applicant_name')
                                    <svg class="ml-1 w-4 h-4 {{ $sortDirection === 'asc' ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                    </svg>
                                @endif
                            </div>
                        </th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm cursor-pointer" wire:click="sortBy('province')">
                            <div class="flex items-center">
                                Province
                                @if($sortField === 'province')
                                    <svg class="ml-1 w-4 h-4 {{ $sortDirection === 'asc' ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                    </svg>
                                @endif
                            </div>
                        </th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm">
                            Status
                        </th>
                        <th class="text-left p-4 font-medium text-gray-800 text-sm">
                            Actions
                        </th>
                    </tr>
                </thead>                <tbody class="divide-y divide-gray-200">
                    @forelse($applications as $application)
                        <tr class="hover:bg-gray-50">
                            <td class="p-4">
                                <div class="font-medium text-gray-700">{{ $application['reference_id'] }}</div>
                            </td>
                            <td class="p-4">
                                <div class="text-sm text-gray-900 line-clamp-2">{{ $application['title'] }}</div>
                            </td>
                            <td class="p-4">
                                <div class="font-medium text-gray-700">{{ $application['applicant_name'] }}</div>
                            </td>
                            <td class="p-4">
                                <div class="text-sm text-gray-900">{{ $application['province'] }}</div>
                            </td>
                            <td class="p-4">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    {{ $application['status'] }}
                                </span>
                            </td>
                            <td class="p-4">
                                <div class="flex items-center space-x-2">
                                    <button wire:click="editApplication({{ $application['id'] }})" 
                                            class="p-1 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-700" 
                                            title="Edit Application">
                                        <span class="material-symbols-outlined text-sm">edit</span>
                                    </button>
                                    <button wire:click="viewApplication({{ $application['id'] }})" 
                                            class="p-1 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-700" 
                                            title="View Application">
                                        <span class="material-symbols-outlined text-sm">visibility</span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="p-8 text-center text-gray-500">
                                <div class="flex flex-col items-center">
                                    <span class="material-symbols-outlined text-4xl mb-2 text-gray-300">description</span>
                                    <p>No applications found matching your search criteria.</p>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>        <!-- Pagination -->
        <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div class="text-sm text-gray-700">
                    Showing
                    <span class="font-medium">{{ count($applications) > 0 ? (($links['current_page'] - 1) * $links['per_page']) + 1 : 0 }}</span>
                    to
                    <span class="font-medium">{{ min($links['current_page'] * $links['per_page'], $links['total']) }}</span>
                    of
                    <span class="font-medium">{{ $links['total'] }}</span>
                    applications
                </div>
                <div class="flex items-center space-x-1">
                    @if($links['current_page'] <= 1)
                        <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                            <span class="hidden sm:inline mr-1">Previous</span>
                            <span class="material-symbols-outlined text-sm">chevron_left</span>
                        </button>
                    @else
                        <button wire:click="setPage({{ max($links['current_page'] - 1, 1) }})" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                            <span class="hidden sm:inline mr-1">Previous</span>
                            <span class="material-symbols-outlined text-sm">chevron_left</span>
                        </button>
                    @endif
                    
                    @for ($i = 1; $i <= $links['last_page']; $i++)
                        @if($links['current_page'] == $i)
                            <button class="px-3 py-1.5 text-sm bg-green-600 text-white rounded-md hover:bg-green-700">{{ $i }}</button>
                        @else
                            <button wire:click="setPage({{ $i }})" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 hover:border-green-200">{{ $i }}</button>
                        @endif
                    @endfor
                    
                    @if($links['current_page'] >= $links['last_page'])
                        <button class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 opacity-50 cursor-not-allowed flex items-center">
                            <span class="hidden sm:inline mr-1">Next</span>
                            <span class="material-symbols-outlined text-sm">chevron_right</span>
                        </button>
                    @else
                        <button wire:click="setPage({{ min($links['current_page'] + 1, $links['last_page']) }})" class="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-50 flex items-center">
                            <span class="hidden sm:inline mr-1">Next</span>
                            <span class="material-symbols-outlined text-sm">chevron_right</span>
                        </button>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
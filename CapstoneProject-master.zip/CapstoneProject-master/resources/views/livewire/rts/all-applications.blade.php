<div class="p-6">
    <!-- Header Section -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-700 mb-1">All Applications</h1>
        <p class="text-gray-600">View and manage all submitted applications for certificate generation</p>
    </div>

    <!-- Content Placeholder -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div class="text-center">
            <span class="material-symbols-outlined text-6xl text-gray-300 mb-4 block">apps</span>
            <h3 class="text-lg font-medium text-gray-900 mb-2">All Applications View</h3>
            <p class="text-gray-500 mb-4">This section will display all applications with filtering and sorting capabilities.</p>
            <div class="text-sm text-gray-400">
                Features to be implemented:
                <ul class="mt-2 text-left max-w-md mx-auto space-y-1">
                    <li>• Application list with status indicators</li>
                    <li>• Search and filter functionality</li>
                    <li>• Bulk actions for certificate generation</li>
                    <li>• Member list verification</li>
                </ul>
            </div>
        </div>
    </div>
</div> 
<div class="p-4 lg:p-6">
    <!-- Welcome Card -->
    <div class="bg-gradient-to-r from-green-500/85 to-green-300/80 rounded-lg p-5 mb-6 text-white shadow-lg flex items-center justify-between"> 
        <div>
            <h1 class="text-xl sm:text-2xl font-bold mb-2">
                Provincial Office Dashboard 👋
            </h1>
            <p class="text-white/90">Oversee provincial operations and performance</p>
        </div>
        <div class="flex items-center space-x-3 ml-4">
            <img src="{{ asset('images/pca-logo.svg') }}" 
                 alt="PCA Logo" 
                 class="h-24 w-auto object-contain transition-transform hover:scale-105 filter drop-shadow-[0_0_4px_rgba(255,255,255,1)]">
        </div>
    </div>

    <!-- Dashboard Widgets -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-lg p-4 lg:p-6 shadow-sm border">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500">For Validation</p>
                    <p class="text-2xl font-bold text-gray-900">18</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg p-4 lg:p-6 shadow-sm border">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Validated Applications</p>
                    <p class="text-2xl font-bold text-gray-900">45</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg p-4 lg:p-6 shadow-sm border">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Pending Applications</p>
                    <p class="text-2xl font-bold text-gray-900">12</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg p-4 lg:p-6 shadow-sm border">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <svg class="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Endorsed to Regional</p>
                    <p class="text-2xl font-bold text-gray-900">23</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->

    <div class="bg-white rounded-lg shadow-sm border">
                    <div class="p-4 lg:p-6 border-b">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                            <div>
                                <h2 class="text-lg font-semibold text-gray-900">All Application</h2>
                                <p class="text-sm text-gray-500">Total Application: 04</p>
                            </div>
                            <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
                                <div class="relative">
                                    <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                    </svg>
                                    <input
                                        type="text"
                                        placeholder="Type to search..."
                                        class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent w-full sm:w-auto"
                                    >
                                </div>
                                <a 
                                    href="{{ route('applications.create') }}"
                                    class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center justify-center space-x-2 transition-colors"
                                >
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                    </svg>
                                    <span>Add Application</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Table -->
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="text-left p-4 font-medium text-gray-700 text-sm">Reference ID</th>
                                    <th class="text-left p-4 font-medium text-gray-700 text-sm">Application Title</th>
                                    <th class="text-left p-4 font-medium text-gray-700 text-sm hidden sm:table-cell">Cooperative Name</th>
                                    <th class="text-left p-4 font-medium text-gray-700 text-sm hidden md:table-cell">Category</th>
                                    <th class="text-left p-4 font-medium text-gray-700 text-sm hidden lg:table-cell">Last Update</th>
                                    <th class="text-left p-4 font-medium text-gray-700 text-sm">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach([
                                    ['id' => 'DDA48032001', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Jane Cooper', 'category' => 'Infrastructure', 'lastUpdate' => '2025-03-30', 'status' => 'Application Received', 'statusColor' => 'bg-green-100 text-green-800'],
                                    ['id' => 'DDA48032002', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Jane Cooper', 'category' => 'Infrastructure', 'lastUpdate' => '2025-03-30', 'status' => 'Validated', 'statusColor' => 'bg-yellow-100 text-yellow-800'],
                                    ['id' => 'DDA48032003', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Jane Cooper', 'category' => 'Infrastructure', 'lastUpdate' => '2025-03-30', 'status' => 'For Validation', 'statusColor' => 'bg-blue-100 text-blue-800'],
                                    ['id' => 'DDA48032004', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Marvin McKinney', 'category' => 'Shared Facility', 'lastUpdate' => '2025-03-30', 'status' => 'For Validation', 'statusColor' => 'bg-blue-100 text-blue-800'],
                                    ['id' => 'DDA48032005', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Jerome Bell', 'category' => 'Infrastructure', 'lastUpdate' => '2025-03-30', 'status' => 'Pending', 'statusColor' => 'bg-red-100 text-red-800'],
                                    ['id' => 'DDA48032006', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Kathryn Murphy', 'category' => 'Infrastructure', 'lastUpdate' => '2025-03-30', 'status' => 'Pending', 'statusColor' => 'bg-red-100 text-red-800'],
                                    ['id' => 'DDA48032007', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Jacob Jones', 'category' => 'Infrastructure', 'lastUpdate' => '2025-03-30', 'status' => 'Application Received', 'statusColor' => 'bg-green-100 text-green-800'],
                                    ['id' => 'DDA48032008', 'title' => 'Proposal for Expanding...', 'cooperative' => 'Jane Cooper', 'category' => 'Shared Facility', 'lastUpdate' => '2025-03-30', 'status' => 'Validated', 'statusColor' => 'bg-yellow-100 text-yellow-800']
                                ] as $app)
                                <tr class="hover:bg-gray-50">
                                    <td class="p-4 text-sm text-gray-900">{{ $app['id'] }}</td>
                                    <td class="p-4 text-sm text-gray-900">{{ $app['title'] }}</td>
                                    <td class="p-4 text-sm text-gray-600 hidden sm:table-cell">{{ $app['cooperative'] }}</td>
                                    <td class="p-4 text-sm text-gray-600 hidden md:table-cell">{{ $app['category'] }}</td>
                                    <td class="p-4 text-sm text-gray-600 hidden lg:table-cell">{{ $app['lastUpdate'] }}</td>
                                    <td class="p-4">
                                        <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full {{ $app['statusColor'] }}">
                                            {{ $app['status'] }}
                                        </span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="p-4 lg:p-6 border-t bg-gray-50">
                        <div class="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
                            <p class="text-sm text-gray-500">Showing page 1 to 8 of table entries</p>
                            <div class="flex items-center space-x-2">
                                <button class="px-3 py-1 text-sm border rounded hover:bg-gray-100 transition-colors">1</button>
                                <button class="px-3 py-1 text-sm text-gray-500 hover:text-gray-700 transition-colors">2</button>
                                <button class="px-3 py-1 text-sm text-gray-500 hover:text-gray-700 transition-colors">3</button>
                                <button class="px-3 py-1 text-sm text-gray-500 hover:text-gray-700 transition-colors">4</button>
                                <span class="text-sm text-gray-500">...</span>
                                <button class="px-3 py-1 text-sm text-gray-500 hover:text-gray-700 transition-colors">40</button>
                                <button class="px-3 py-1 text-sm text-gray-500 hover:text-gray-700 transition-colors">→</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div> 
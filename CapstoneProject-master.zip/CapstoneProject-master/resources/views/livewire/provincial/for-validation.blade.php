<div class="p-4 lg:p-6">
    <!-- Page Header -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">For Validation</h1>
        <p class="text-gray-600">Applications awaiting provincial validation</p>
    </div>

    <!-- Filters and Actions -->
    <div class="bg-white rounded-lg shadow-sm border mb-6">
        <div class="p-4 border-b">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                <div class="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
                    <div class="relative">
                        <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                        <input
                            type="text"
                            placeholder="Search applications..."
                            class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent w-full sm:w-auto"
                        >
                    </div>
                    <select class="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <option>All Categories</option>
                        <option>Infrastructure</option>
                        <option>Equipment</option>
                        <option>Training</option>
                        <option>Shared Facility</option>
                    </select>
                </div>
                <div class="flex space-x-2">
                    <button class="px-4 py-2 bg-purple-500 text-white rounded-lg text-sm font-medium hover:bg-purple-600 transition-colors">
                        Validate Selected
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Applications Table -->
    <div class="bg-white rounded-lg shadow-sm border">
        <div class="p-4 lg:p-6 border-b">
            <h2 class="text-lg font-semibold text-gray-900">Applications for Validation</h2>
            <p class="text-sm text-gray-500">Total applications: 18</p>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left p-4 w-10">
                            <input type="checkbox" class="rounded border-gray-300 text-purple-600 focus:ring-purple-500">
                        </th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm">Reference ID</th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm">Applicant</th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm hidden sm:table-cell">Category</th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm hidden md:table-cell">Amount</th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm hidden lg:table-cell">Submitted</th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm">Priority</th>
                        <th class="text-left p-4 font-medium text-gray-700 text-sm">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @foreach([
                        ['id' => 'DDA48032001', 'applicant' => 'Albay Rice Farmers Cooperative', 'category' => 'Infrastructure', 'amount' => '₱850,000', 'submitted' => '2024-01-15', 'priority' => 'High', 'priorityColor' => 'bg-red-100 text-red-800'],
                        ['id' => 'DDA48032002', 'applicant' => 'Legazpi Multi-Purpose Cooperative', 'category' => 'Equipment', 'amount' => '₱450,000', 'submitted' => '2024-01-14', 'priority' => 'Medium', 'priorityColor' => 'bg-yellow-100 text-yellow-800'],
                        ['id' => 'DDA48032003', 'applicant' => 'Daraga Agricultural Cooperative', 'category' => 'Training', 'amount' => '₱120,000', 'submitted' => '2024-01-13', 'priority' => 'Low', 'priorityColor' => 'bg-green-100 text-green-800'],
                        ['id' => 'DDA48032004', 'applicant' => 'Tabaco Fishermen Cooperative', 'category' => 'Shared Facility', 'amount' => '₱680,000', 'submitted' => '2024-01-12', 'priority' => 'High', 'priorityColor' => 'bg-red-100 text-red-800'],
                        ['id' => 'DDA48032005', 'applicant' => 'Guinobatan Farmers Union', 'category' => 'Infrastructure', 'amount' => '₱920,000', 'submitted' => '2024-01-11', 'priority' => 'Medium', 'priorityColor' => 'bg-yellow-100 text-yellow-800']
                    ] as $app)
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <input type="checkbox" class="rounded border-gray-300 text-purple-600 focus:ring-purple-500">
                        </td>
                        <td class="p-4 text-sm font-medium text-gray-900">{{ $app['id'] }}</td>
                        <td class="p-4 text-sm text-gray-900">{{ $app['applicant'] }}</td>
                        <td class="p-4 text-sm text-gray-600 hidden sm:table-cell">{{ $app['category'] }}</td>
                        <td class="p-4 text-sm text-gray-600 hidden md:table-cell">{{ $app['amount'] }}</td>
                        <td class="p-4 text-sm text-gray-600 hidden lg:table-cell">{{ $app['submitted'] }}</td>
                        <td class="p-4">
                            <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full {{ $app['priorityColor'] }}">
                                {{ $app['priority'] }}
                            </span>
                        </td>
                        <td class="p-4">
                            <div class="flex space-x-2">
                                <button class="text-purple-600 hover:text-purple-800 text-sm font-medium">Validate</button>
                                <button class="text-gray-600 hover:text-gray-800 text-sm font-medium">View</button>
                                <button class="text-red-600 hover:text-red-800 text-sm font-medium">Reject</button>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="p-4 lg:p-6 border-t bg-gray-50">
            <div class="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
                <p class="text-sm text-gray-500">Showing 1 to 5 of 18 entries</p>
                <div class="flex items-center space-x-2">
                    <button class="px-3 py-1 text-sm border rounded hover:bg-gray-100 transition-colors">Previous</button>
                    <button class="px-3 py-1 text-sm bg-purple-500 text-white rounded">1</button>
                    <button class="px-3 py-1 text-sm border rounded hover:bg-gray-100 transition-colors">2</button>
                    <button class="px-3 py-1 text-sm border rounded hover:bg-gray-100 transition-colors">3</button>
                    <button class="px-3 py-1 text-sm border rounded hover:bg-gray-100 transition-colors">4</button>
                    <button class="px-3 py-1 text-sm border rounded hover:bg-gray-100 transition-colors">Next</button>
                </div>
            </div>
        </div>
    </div>
</div> 
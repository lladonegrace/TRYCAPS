<div class="p-4 lg:p-6">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Pending Applications</h1>
        <p class="text-gray-600">Applications pending provincial office review</p>
    </div>

    <div class="bg-white rounded-lg shadow-sm border p-6">
        <div class="text-center py-8">
            <svg class="mx-auto h-12 w-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
            <h3 class="mt-2 text-sm font-medium text-gray-900">Pending Applications</h3>
            <p class="mt-1 text-sm text-gray-500">Content for pending applications will be implemented here.</p>
        </div>
    </div>
</div>
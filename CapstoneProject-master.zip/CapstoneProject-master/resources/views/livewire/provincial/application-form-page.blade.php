<div class="min-h-screen bg-gray-50">
    {{-- Reduce top padding further: pt-0 for mobile, lg:pt-1 for large screens --}}
    <div class="bg-white shadow-sm border-b px-4 pt-0 pb-3 lg:px-6 lg:pt-2 lg:pb-4">
        <div class="flex flex-col sm:flex-row sm:items-center gap-3">
            <a href="{{ route('dashboard') }}" class="flex items-center text-gray-600 hover:text-gray-900 transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                <span class="ml-2">Back to Dashboard</span>
            </a>
            <div class="sm:border-l sm:border-gray-300 sm:pl-4">
                <h1 class="text-lg sm:text-xl font-semibold text-gray-900">Add New Application</h1>
                <p class="text-sm text-gray-500">Step {{ $currentStep }} of {{ $totalSteps }}</p>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto p-4 sm:p-6">
        <!-- Mobile Step Indicator -->
        <div class="sm:hidden mb-6">
            <div class="flex items-center justify-between px-2 py-3 bg-white rounded-lg shadow-sm border">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white text-sm font-medium">
                        {{ $currentStep }}
                    </div>
                    <div>
                        <p class="font-medium text-gray-900">{{ $steps[$currentStep - 1]['title'] }}</p>
                        <p class="text-xs text-gray-500">{{ $steps[$currentStep - 1]['description'] }}</p>
                    </div>
                </div>
                <p class="text-sm text-gray-500">Step {{ $currentStep }} of {{ $totalSteps }}</p>
            </div>
            <!-- Mobile Progress Bar -->
            <div class="mt-4 h-1 bg-gray-200 rounded-full overflow-hidden">
                <div class="h-full bg-green-500 transition-all duration-300 ease-in-out"
                    style="width: {{ ($currentStep - 1) / ($totalSteps - 1) * 100 }}%">
                </div>
            </div>
        </div>

        <!-- Desktop Step Indicator -->
        <div class="hidden sm:block mb-8">
            <div class="flex items-center px-4 pb-5"> 
                @foreach($steps as $index => $step)
                    {{-- Step Circle and Text Block --}}
                    <div class="relative flex flex-col items-center text-center">
                        {{-- Step Circle --}}
                        <div class="w-10 h-10 rounded-full border-2 flex items-center justify-center text-sm font-medium
                            {{ $step['number'] < $currentStep ? 'bg-green-500 border-green-500 text-white' : 
                               ($step['number'] === $currentStep ? 'border-green-500 bg-white text-green-600' : 
                               'bg-white border-gray-300 text-gray-500') }}">
                            @if($step['number'] < $currentStep)
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                </svg>
                            @else
                                {{ $step['number'] }}
                            @endif
                        </div>
                        {{-- Step Title & Description --}}
                        {{-- This text hangs 2rem below the circle (-bottom-8) and has its own height --}}
                        <div class="absolute -bottom-8 text-center w-32">
                            <p class="text-xs font-medium {{ $step['number'] <= $currentStep ? 'text-green-600' : 'text-gray-500' }}">
                                {{ $step['title'] }}
                            </p>
                            <p class="text-xs {{ $step['number'] <= $currentStep ? 'text-green-500' : 'text-gray-400' }}">
                                {{ $step['description'] }}
                            </p>
                        </div>
                    </div>
                    
                    {{-- Connecting Line (if not the last step) --}}
                    @if($index < count($steps) - 1)
                        <div class="flex-1 h-0.5 mx-2
                            {{ $step['number'] < $currentStep ? 'bg-green-500' : 'bg-gray-300' }}">
                        </div>
                    @endif
                @endforeach
            </div>
        </div>

        <!-- Form Content -->
        <div class="bg-white rounded-lg shadow-sm border p-4 sm:p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-6">
                {{ $steps[$currentStep - 1]['title'] }}
                <span class="text-sm font-normal text-gray-500 block sm:inline sm:ml-2">
                    {{ $steps[$currentStep - 1]['description'] }}
                </span>
            </h2>

            <form wire:submit.prevent="submitForm" class="space-y-6">
                <!-- Step 1: Basic Information -->
                @if($currentStep === 1)
                    <div class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                            <div class="col-span-1">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Application Title</label>
                                <input type="text" wire:model="applicationTitle"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                                    placeholder="Enter application title">
                                @error('applicationTitle') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-span-1">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                                <select wire:model="category"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
                                    <option value="">Select category</option>
                                    <option value="infrastructure">Infrastructure</option>
                                    <option value="shared-facility">Shared Facility</option>
                                    <option value="equipment">Equipment</option>
                                </select>
                                @error('category') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                            <textarea wire:model="description" rows="4"
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                                placeholder="Describe your application"></textarea>
                            @error('description') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                    </div>
                @endif

                <!-- Step 2: Cooperative Details -->
                @if($currentStep === 2)
                    <div class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Cooperative Name</label>
                                <input type="text" wire:model="cooperativeName"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="Enter cooperative name">
                                @error('cooperativeName') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Registration Number</label>
                                <input type="text" wire:model="registrationNumber"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="Enter registration number">
                                @error('registrationNumber') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Contact Person</label>
                                <input type="text" wire:model="contactPerson"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="Enter contact person name">
                                @error('contactPerson') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                                <input type="tel" wire:model="phoneNumber"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="Enter phone number">
                                @error('phoneNumber') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>
                @endif

                <!-- Step 3: Project Information -->
                @if($currentStep === 3)
                    <div class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Project Type</label>
                                <select wire:model="projectType"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                                    <option value="">Select project type</option>
                                    <option value="new">New Project</option>
                                    <option value="expansion">Expansion</option>
                                    <option value="renovation">Renovation</option>
                                </select>
                                @error('projectType') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Expected Duration</label>
                                <input type="text" wire:model="expectedDuration"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="e.g., 6 months">
                                @error('expectedDuration') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Project Objectives</label>
                            <textarea wire:model="projectObjectives" rows="4"
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                placeholder="Describe the project objectives"></textarea>
                            @error('projectObjectives') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                    </div>
                @endif

                <!-- Step 4: Financial Details -->
                @if($currentStep === 4)
                    <div class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Total Budget</label>
                                <input type="number" wire:model="totalBudget"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="Enter total budget">
                                @error('totalBudget') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Requested Amount</label>
                                <input type="number" wire:model="requestedAmount"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                    placeholder="Enter requested amount">
                                @error('requestedAmount') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Funding Source</label>
                            <select wire:model="fundingSource"
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                                <option value="">Select funding source</option>
                                <option value="government">Government Grant</option>
                                <option value="private">Private Funding</option>
                                <option value="mixed">Mixed Funding</option>
                            </select>
                            @error('fundingSource') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                    </div>
                @endif

                <!-- Step 5: Review -->
                @if($currentStep === 5)
                    <div class="space-y-6">
                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                            <h3 class="text-lg font-medium text-yellow-800 mb-2">Review Your Application</h3>
                            <p class="text-sm text-yellow-700">
                                Please review all the information you've provided before submitting your application.
                            </p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-medium text-gray-900 mb-2">Application Summary</h4>
                                <div class="space-y-2">
                                    <p class="text-sm text-gray-600">Title: {{ $applicationTitle }}</p>
                                    <p class="text-sm text-gray-600">Category: {{ $category }}</p>
                                    <p class="text-sm text-gray-600">Cooperative: {{ $cooperativeName }}</p>
                                </div>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-medium text-gray-900 mb-2">Financial Summary</h4>
                                <div class="space-y-2">
                                    <p class="text-sm text-gray-600">Total Budget: ₱{{ number_format($totalBudget ?? 0, 2) }}</p>
                                    <p class="text-sm text-gray-600">Requested: ₱{{ number_format($requestedAmount ?? 0, 2) }}</p>
                                    <p class="text-sm text-gray-600">Source: {{ $fundingSource }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            </form>
        </div>

        <!-- Navigation Buttons - Made more mobile-friendly -->
        <div class="flex flex-col sm:flex-row justify-between gap-3 sm:gap-0">
            <button wire:click="previousStep"
                class="order-2 sm:order-1 w-full sm:w-auto px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 flex items-center justify-center space-x-2"
                {{ $currentStep === 1 ? 'disabled' : '' }}>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                </svg>
                <span>Previous</span>
            </button>

            @if($currentStep === $totalSteps)
                <button wire:click="submitForm"
                    class="order-1 sm:order-2 w-full sm:w-auto px-4 py-2 text-sm font-medium text-white bg-green-500 border border-transparent rounded-lg hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 flex items-center justify-center">
                    Submit Application
                </button>
            @else
                <button wire:click="nextStep"
                    class="order-1 sm:order-2 w-full sm:w-auto px-4 py-2 text-sm font-medium text-white bg-green-500 border border-transparent rounded-lg hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 flex items-center justify-center space-x-2">
                    <span>Next</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </button>
            @endif
        </div>
    </div>
</div>

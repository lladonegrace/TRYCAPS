@props(['user'])

<div x-data="{ isOpen: false }" class="relative">
    <button 
        @click="isOpen = !isOpen" 
        class="flex items-center space-x-3 w-full hover:bg-gray-50 p-4 rounded-lg transition-colors duration-150"
    >
        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
            <span class="text-sm font-medium text-green-600">{{ substr($user->name ?? 'TA', 0, 2) }}</span>
        </div>        <div class="flex-1 text-left">
            <p class="text-[13px] font-medium text-gray-900 leading-tight">{{$user->name ?? 'Try Account'}}</p>
            <p class="text-[11px] text-gray-500 leading-tight">{{ $user->roles->first()->RoleName ?? 'No Role' }}</p>
        </div>
        <svg class="w-4 h-4 text-gray-400 flex-shrink-0" :class="{'rotate-180': isOpen}" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
    </button>

    <!-- Dropdown Menu -->
    <div 
        x-show="isOpen" 
        @click.away="isOpen = false"
        x-transition:enter="transition ease-out duration-100"
        x-transition:enter-start="transform opacity-0 scale-95"
        x-transition:enter-end="transform opacity-100 scale-100"
        x-transition:leave="transition ease-in duration-75"
        x-transition:leave-start="transform opacity-100 scale-100"
        x-transition:leave-end="transform opacity-0 scale-95"
        class="absolute bottom-full right-2 mb-1 w-60 bg-white shadow-lg rounded-lg border"
        style="display: none;"
    >
        <!-- User Info -->
        <div class="px-4 py-3">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                        <span class="text-sm font-medium text-green-600">{{ substr($user->name ?? 'TA', 0, 2) }}</span>
                    </div>
                </div>
                <div class="ml-3">
                    <p class="text-[13px] font-medium text-gray-900 truncate">{{$user->name ?? 'Try Account' }}</p>
                    <p class="text-[11px] text-gray-500 truncate">{{ $user->email ?? 'try@example.com' }}</p>
                </div>
            </div>
        </div>

        <!-- Menu Items -->
        <div class="border-t pl-2 mb-0">
            <form method="POST" action="{{ route('logout') }}" class="w-full">
                @csrf
                <button type="submit" class="flex w-full items-center px-4 py-2 text-[13px] text-gray-600 hover:bg-gray-50">
                    <svg class="mr-3 h-4 w-4 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </button>
            </form>
        </div>
    </div>
</div>
@extends('layouts.app')

@section('content')
<div class="bg-gray-50 flex overflow-hidden" x-data="{ isSidebarOpen: false }">
    <!-- Mobile overlay -->
    <div 
        x-show="isSidebarOpen"
        class="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
        @click="isSidebarOpen = false">
    </div>

    <!-- Sidebar Navigation (Livewire Component) -->
    <aside class="fixed inset-y-0 left-0 w-64 bg-white border-r transform transition-transform duration-300 ease-in-out flex flex-col lg:translate-x-0 z-30"
        :class="isSidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        <!-- Fixed Header -->
        <div class="flex-shrink-0 border-b">
            <div class="flex items-center h-16 px-6">
                <div class="flex items-center">
                    <svg class="w-8 h-8 text-green-600" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
                    </svg>
                    <span class="font-bold text-xl ml-3 text-gray-900">PCAppTrack</span>
                </div>
                <button class="lg:hidden ml-auto" @click="isSidebarOpen = false">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>

        <!-- Livewire Sidebar Navigation Component -->
        @livewire('sidebar-navigation')

        <!-- Fixed User Profile -->
        <div class="border-t">
            <x-user-profile-dropdown :user="auth()->user()" />
        </div>
    </aside>

    <!-- Main Content Area (Livewire Component) -->
    <main class="flex-1 ml-0 lg:ml-64 min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-white py-4 -mt-1 mx-4 lg:mx-6 rounded-lg shadow-sm border mt-4 pl-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <button class="lg:hidden text-gray-500 hover:text-gray-600" @click="isSidebarOpen = true"> 
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                    <div class="flex items-center space-x-2 text-gray-600" x-data="{ 
                        currentTime: '',
                        currentDate: '',
                        init() {
                            this.updateTime();
                            setInterval(() => {
                                this.updateTime();
                            }, 1000);
                        },
                        updateTime() {
                            const now = new Date();
                            const phTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Manila' }));
                            
                            this.currentTime = phTime.toLocaleString('en-US', {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit',
                                hour12: true
                            });
                            
                            this.currentDate = phTime.toLocaleString('en-US', {
                                weekday: 'long',
                                month: 'long',
                                day: '2-digit',
                                year: 'numeric'
                            });
                        }
                    }">
                        <svg class="hidden sm:inline w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                        <div class="text-sm">
                            <span x-text="currentDate"></span>
                            <span class="mx-1">|</span>
                            <span x-text="currentTime" class="inline-block w-28 text-left"></span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Dynamic Content Area (Dashboard Router) -->
        <div class="flex-1">
            @livewire('dashboard-router', ['component' => $component ?? null, 'id' => $id ?? null])
        </div>
    </main>
</div>
@endsection

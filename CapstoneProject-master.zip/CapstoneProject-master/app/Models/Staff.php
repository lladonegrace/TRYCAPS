<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;

    protected $primaryKey = 'StaffID';
    protected $table = 'staff';

    protected $fillable = [
        'UserID',
        'OfficeID',
        'FullName',
        'Position',
        'ContactDetails'
    ];

    /**
     * Get the user that owns this staff record.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'UserID', 'id');
    }

    /**
     * Get the office this staff member belongs to.
     */
    public function office()
    {
        return $this->belongsTo(Office::class, 'OfficeID', 'OfficeID');
    }

    /**
     * Get all permissions assigned to this staff member.
     */
    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'staff_permission', 'StaffID', 'PermissionID');
    }

    /**
     * Check if staff has a specific permission.
     */
    public function hasPermission($permissionName)
    {
        return $this->permissions()->where('PermissionName', $permissionName)->exists();
    }

    /**
     * Check if staff has any of the given permissions.
     */
    public function hasAnyPermission(array $permissions)
    {
        return $this->permissions()->whereIn('PermissionName', $permissions)->exists();
    }

    /**
     * Check if staff has all given permissions.
     */
    public function hasAllPermissions(array $permissions)
    {
        $staffPermissions = $this->permissions()->pluck('PermissionName')->toArray();
        return count(array_intersect($permissions, $staffPermissions)) === count($permissions);
    }

    /**
     * All staff have View permission by default.
     */
    public function canView()
    {
        return true; // All staff can view
    }

    /**
     * Check if staff can edit.
     */
    public function canEdit()
    {
        return $this->hasPermission('Edit');
    }

    /**
     * Check if staff can create.
     */
    public function canCreate()
    {
        return $this->hasPermission('Create');
    }

    /**
     * Check if staff can delete.
     */
    public function canDelete()
    {
        return $this->hasPermission('Delete');
    }
}
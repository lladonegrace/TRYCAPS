<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Office extends Model
{
    use HasFactory;

    protected $primaryKey = 'OfficeID';

    protected $fillable = [
        'OfficeName',
        'OfficeType',
        'Location',
        'ContactInfo',
        'HeadName'
    ];

    /**
     * Get all staff members in this office.
     */
    public function staff()
    {
        return $this->hasMany(Staff::class, 'OfficeID', 'OfficeID');
    }
} 
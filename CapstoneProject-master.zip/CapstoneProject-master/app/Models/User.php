<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
    
    /**
     * Get the last activity time for this user from the session.
     */
    public function lastActivity()
    {
        $session = \DB::table('sessions')
            ->where('user_id', $this->id)
            ->orderBy('last_activity', 'desc')
            ->first();
            
        return $session ? \Carbon\Carbon::createFromTimestamp($session->last_activity) : null;
    }

    /**
     * Get all roles that belong to this user.
     */
    public function roles()
    {
        return $this->belongsToMany(Role::class, 'user_role', 'UserID', 'RoleID');
    }

    /**
     * Get all staff records for this user (a user can belong to multiple staff/offices).
     */
    public function staff()
    {
        return $this->hasMany(Staff::class, 'UserID', 'id');
    }

    /**
     * Check if user has a specific role.
     */
    public function hasRole($roleName)
    {
        return $this->roles()->where('RoleName', $roleName)->exists();
    }

    /**
     * Check if user has any of the given roles.
     */
    public function hasAnyRole(array $roles)
    {
        return $this->roles()->whereIn('RoleName', $roles)->exists();
    }

    /**
     * Check if user has a specific permission.
     */
    public function hasPermission($permissionName)
    {
        return $this->roles()
            ->whereHas('permissions', function ($query) use ($permissionName) {
                $query->where('PermissionName', $permissionName);
            })->exists();
    }

    /**
     * Get all permissions for this user through roles.
     */
    public function permissions()
    {
        return Permission::whereHas('roles', function ($query) {
            $query->whereIn('RoleID', $this->roles()->pluck('RoleID'));
        });
    }

    /**
     * Get current staff member for this user (if any).
     */
    public function currentStaff()
    {
        return $this->staff()->first();
    }

    /**
     * Check if current user's staff has specific permission.
     */
    public function staffHasPermission($permissionName)
    {
        $staff = $this->currentStaff();
        return $staff ? $staff->hasPermission($permissionName) : false;
    }

    /**
     * Check if current user's staff can view (all staff can view by default).
     */
    public function staffCanView()
    {
        return $this->staff()->exists(); // If user has staff, they can view
    }

    /**
     * Check if current user's staff can edit.
     */
    public function staffCanEdit()
    {
        return $this->staffHasPermission('Edit');
    }

    /**
     * Check if current user's staff can create.
     */
    public function staffCanCreate()
    {
        return $this->staffHasPermission('Create');
    }

    /**
     * Check if current user's staff can delete.
     */
    public function staffCanDelete()
    {
        return $this->staffHasPermission('Delete');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    use HasFactory;

    protected $primaryKey = 'RoleID';

    protected $fillable = [
        'RoleName',
        'Description'
    ];

    /**
     * Get all users that belong to this role.
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_role', 'RoleID', 'UserID');
    }

    /**
     * Get all permissions that belong to this role.
     */
    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'role_permission', 'RoleID', 'PermissionID');
    }
}
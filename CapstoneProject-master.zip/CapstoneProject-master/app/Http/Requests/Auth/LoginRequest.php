<?php

namespace App\Http\Requests\Auth;

use App\Models\LoginAttempt;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'string', 'email'],
            'password' => ['required', 'string'],
        ];
    }

    /**
     * Attempt to authenticate the request's credentials.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function authenticate(): void
    {
        // First check if already rate limited to avoid confusion with error messages
        if (RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            $seconds = RateLimiter::availableIn($this->throttleKey());
            throw ValidationException::withMessages([
                'email' => 'Too many attempts. Try again in ' . ceil($seconds / 60) . ' minute/s or contact your Focal Person.',
            ]);
        }

        if (! Auth::attempt($this->only('email', 'password'), $this->boolean('remember'))) {
            // Record the failed login attempt
            LoginAttempt::create([
                'email' => $this->email,
                'ip_address' => $this->ip(),
                'user_agent' => $this->userAgent(),
                'successful' => false,
            ]);

            RateLimiter::hit($this->throttleKey(), 300); // Set 5 minute decay time here too

            throw ValidationException::withMessages([
                'email' => 'Invalid credentials. Please try again or contact your Regional Focal Person.',
            ]);
        }

        // Record the successful login attempt
        LoginAttempt::create([
            'email' => $this->email,
            'ip_address' => $this->ip(),
            'user_agent' => $this->userAgent(),
            'successful' => true,
        ]);

        RateLimiter::clear($this->throttleKey());
    }

    /**
     * Ensure the login request is not rate limited.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout($this));
        
        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw ValidationException::withMessages([
            'email' => 'Too many attempts. Try again in ' . ceil($seconds / 60) . ' minutes or contact your Focal Person.',
        ]);
    }

    /**
     * Get the rate limiting throttle key for the request.
     */
    public function throttleKey(): string
    {
        return Str::transliterate(Str::lower($this->string('email')).'|'.$this->ip());
    }
}

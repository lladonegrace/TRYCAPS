<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Register RTS Livewire component aliases
        Livewire::component('rts.all-applications', \App\Livewire\Rts\AllApplications::class);
        Livewire::component('rts.for-eligibility-check', \App\Livewire\Rts\ForEligibilityCheck::class);
        Livewire::component('rts.pending-application', \App\Livewire\Rts\PendingApplication::class);
        Livewire::component('rts.dashboard', \App\Livewire\Rts\Dashboard::class);
        Livewire::component('rts.eligibility-check-details', \App\Livewire\Rts\EligibilityCheckDetails::class);
    }
}

<?php

namespace App\Livewire;

use Livewire\Component;
use Livewire\Attributes\On;
use Illuminate\Support\Facades\Auth;

class DashboardRouter extends Component
{
    public $currentComponent;
    public $currentComponentParams = [];

    public function mount($component = null, $id = null)
    {
        if ($component) {
            $this->currentComponent = $this->getComponentForRoute($component);
            
            // For components that need an ID parameter
            if ($id) {
                // Log that we received an ID parameter
                \Log::info('DashboardRouter - Received ID: ' . $id . ' for component: ' . $component);
                $this->currentComponentParams = ['id' => $id];
            }
        } else {
            $this->currentComponent = $this->getDefaultComponent();
        }
    }

    private function getComponentForRoute($routeComponent)
    {
        $user = Auth::user();
        
        if (!$user || $user->roles->isEmpty()) {
            return 'default.dashboard';
        }

        $roleName = $user->roles->first()->RoleName;
        \Log::info('DashboardRouter - Role: ' . $roleName . ', Route Component: ' . $routeComponent);

        // Map route components to Livewire components based on role
        switch ($roleName) {
            case 'Provincial Office':
                $componentMap = [
                    'dashboard' => 'provincial.dashboard',
                    'for-validation' => 'provincial.for-validation',
                    'validated-application' => 'provincial.validated-application',
                    'pending-application' => 'provincial.pending-application',
                    'endorsed-to-regional' => 'provincial.endorsed-to-regional',
                ];
                break;
                
            case 'Focal Person':
                $componentMap = [
                    'dashboard' => 'focal.dashboard',
                    'all-applications' => 'focal.all-applications',
                    'incoming-applications' => 'focal.incoming-applications',
                    'received-application' => 'focal.received-application',
                    'assigned-application' => 'focal.assigned-application',
                    'progress-monitoring' => 'focal.progress-monitoring',
                    'manage-users' => 'focal.manage-users',
                ];
                break;
                
            case 'Project Development Officer':
                $componentMap = [
                    'dashboard' => 'pdo.dashboard',
                    'for-review' => 'pdo.for-review',
                    'under-review' => 'pdo.under-review',
                    'approved-application' => 'pdo.approved-application',
                    'for-progress-monitoring' => 'pdo.for-progress-monitoring',
                ];
                break;
                
            case 'RTS':
                $componentMap = [
                    'dashboard' => 'rts.dashboard',
                    'rts-all-applications' => 'rts.all-applications',
                    'for-eligibility-check' => 'rts.for-eligibility-check',
                    'eligibility-check-details' => 'rts.eligibility-check-details',
                    'rts-pending-application' => 'rts.pending-application',
                ];
                break;
                
            default:
                $componentMap = ['dashboard' => 'default.dashboard'];
        }

        $resolvedComponent = $componentMap[$routeComponent] ?? $this->getDefaultComponent();
        \Log::info('DashboardRouter - Resolved component: ' . $resolvedComponent);
        
        return $resolvedComponent;
    }

    private function getDefaultComponent()
    {
        $user = Auth::user();
        
        if (!$user || $user->roles->isEmpty()) {
            return 'default.dashboard';
        }

        $roleName = $user->roles->first()->RoleName;

        switch ($roleName) {
            case 'Project Development Officer':
                return 'pdo.dashboard';
            case 'Focal Person':
                return 'focal.dashboard';
            case 'Provincial Office':
                return 'provincial.dashboard';
            case 'RTS':
                return 'rts.dashboard';
            default:
                return 'default.dashboard';
        }
    }

    #[On('navigateTo')]
    public function navigateTo($component)
    {
        $this->currentComponent = $component;
    }

    public function render()
    {
        return view('livewire.dashboard-router', [
            'componentParams' => $this->currentComponentParams
        ]);
    }
}
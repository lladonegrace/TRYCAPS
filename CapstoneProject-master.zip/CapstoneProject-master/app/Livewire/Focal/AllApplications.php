<?php

namespace App\Livewire\Focal;

use Livewire\Component;

class AllApplications extends Component
{
    public function render()
    {
        return view('livewire.focal.all-applications');
    }
} 
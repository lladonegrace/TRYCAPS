<?php

namespace App\Livewire\Focal;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Office;
use App\Models\User;
use App\Models\Staff;
use App\Models\Role;
use App\Models\Permission;
use App\Models\LoginAttempt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class ManageUsers extends Component
{
    use WithPagination;    public $showOfficeModal = false;
    public $showUserModal = false;
    public $showStaffModal = false;
    public $showPermissionModal = false;
    public $showDeleteConfirmModal = false;
    public $editingOffice = null;
    public $editingUser = null;
    public $editingStaff = null;
    public $managingPermissionsStaff = null;
    public $deletingItemId = null;
    public $deletingItemType = null;
    
    // Active tab tracking
    public $activeTab = 'offices';
    public $selectedPermissions = [];
    
    // Search and Filter properties
    public $search = '';
    public $officeTypeFilter = '';
    public $roleFilter = '';
    public $officeFilter = '';
    public $perPage = 5; // Reduced from 10 to 2 to make pagination visible with fewer records
    
    // Login attempts filter properties
    public $loginStatusFilter = '';
    public $loginDateFilter = '';
    public $loginUserFilter = '';  // New filter to show only attempts for existing users
    
    // Office form properties
    public $officeName = '';
    public $officeType = 'Provincial Office';
    public $location = '';
    public $contactInfo = '';
    public $headName = '';
    
    // User form properties
    public $userName = '';
    public $userEmail = '';
    public $userPassword = '';
    public $userRole = '';
    
    // Staff form properties
    public $staffFullName = '';
    public $staffPosition = '';
    public $staffContactDetails = '';
    public $staffOfficeId = '';
    public $staffUserId = '';
    
    protected $rules = [
        'officeName' => 'required|in:Albay PCA Provincial Office,Camarines Norte PCA Provincial Office,Camarines Sur PCA Provincial Office,Sorsogon PCA Provincial Office,Catanduanes PCA Provincial Office,Masbate PCA Provincial Office,PCA Region V Office',
        'officeType' => 'required|in:Provincial Office,Regional Office',
        'location' => 'nullable|string|max:255',
        'contactInfo' => 'nullable|string|max:255',
        'headName' => 'nullable|string|max:100',
        'userName' => 'required|string|max:255',        'userEmail' => 'required|email|unique:users,email',
        'userPassword' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/',
        'userRole' => 'required|exists:roles,RoleID',
        'staffFullName' => 'required|string|max:200',
        'staffPosition' => 'nullable|string|max:100',
        'staffContactDetails' => 'nullable|string|max:255',
        'staffOfficeId' => 'required|exists:offices,OfficeID',
        'staffUserId' => 'required|exists:users,id',
    ];
    
    protected $messages = [
        'userPassword.regex' => 'Password must be at least 8 characters and contain at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&).',
    ];

    protected $queryString = [
        'search' => ['except' => ''],
        'officeTypeFilter' => ['except' => ''],
        'roleFilter' => ['except' => ''],
        'officeFilter' => ['except' => ''],
        'activeTab' => ['except' => 'offices'],
        'loginStatusFilter' => ['except' => ''],
        'loginDateFilter' => ['except' => ''],
        'loginUserFilter' => ['except' => ''],
        'page' => ['except' => 1],
    ];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingOfficeTypeFilter()
    {
        $this->resetPage();
    }

    public function updatingRoleFilter()
    {
        $this->resetPage();
    }

    public function updatingOfficeFilter()
    {
        $this->resetPage();
    }

    public function updatingLoginStatusFilter()
    {
        $this->resetPage();
    }

    public function updatingLoginDateFilter()
    {
        $this->resetPage();
    }

    public function updatingLoginUserFilter()
    {
        $this->resetPage();
    }

    public function clearLoginFilters()
    {
        $this->search = '';
        $this->loginStatusFilter = '';
        $this->loginDateFilter = '';
        $this->loginUserFilter = '';
        $this->resetPage();
    }

    public function clearFilters()
    {
        $this->search = '';
        $this->officeTypeFilter = '';
        $this->roleFilter = '';
        $this->officeFilter = '';
        $this->resetPage();
    }

    public function setActiveTab($tab)
    {
        $this->activeTab = $tab;
        $this->resetPage();
        $this->clearFilters();
    }

    public function openOfficeModal()
    {
        $this->resetOfficeForm();
        $this->showOfficeModal = true;    }
    
    public function closeOfficeModal()
    {
        $this->showOfficeModal = false;
        $this->resetOfficeForm(); // Reset form and close modal
        // Force UI refresh
        $this->dispatch('office-closed');
    }

    public function resetOfficeForm()
    {
        $this->editingOffice = null;
        $this->officeName = '';
        $this->officeType = 'Provincial Office';
        $this->location = '';
        $this->contactInfo = '';
        $this->headName = '';
        $this->resetValidation();
    }

    public function saveOffice()
    {
        $this->validate([
            'officeName' => 'required|in:Albay PCA Provincial Office,Camarines Norte PCA Provincial Office,Camarines Sur PCA Provincial Office,Sorsogon PCA Provincial Office,Catanduanes PCA Provincial Office,Masbate PCA Provincial Office,PCA Region V Office',
            'officeType' => 'required|in:Provincial Office,Regional Office',
            'location' => 'nullable|string|max:255',
            'contactInfo' => 'nullable|string|max:255',
            'headName' => 'nullable|string|max:100',
        ]);        if ($this->editingOffice) {
            $this->editingOffice->update([
                'OfficeName' => $this->officeName,
                'OfficeType' => $this->officeType,
                'Location' => $this->location,
                'ContactInfo' => $this->contactInfo,
                'HeadName' => $this->headName,
            ]);
            
            $this->dispatch('notify', [
                'message' => 'Office updated successfully!', 
                'type' => 'success'
            ]);
            
            $this->showOfficeModal = false;
            $this->resetOfficeForm();
            // Force UI refresh
            $this->dispatch('office-saved');        } else {
            Office::create([
                'OfficeName' => $this->officeName,
                'OfficeType' => $this->officeType,
                'Location' => $this->location,
                'ContactInfo' => $this->contactInfo,
                'HeadName' => $this->headName,
            ]);
            
            $this->dispatch('notify', [
                'message' => 'Office created successfully!', 
                'type' => 'success'
            ]);
            
            $this->showOfficeModal = false;
            $this->resetOfficeForm();
            // Force UI refresh
            $this->dispatch('office-saved');
        }
        
        $this->closeOfficeModal();
    }

    public function editOffice($officeId)
    {
        $this->editingOffice = Office::find($officeId);
        
        if ($this->editingOffice) {
            $this->officeName = $this->editingOffice->OfficeName;
            $this->officeType = $this->editingOffice->OfficeType;
            $this->location = $this->editingOffice->Location ?? '';
            $this->contactInfo = $this->editingOffice->ContactInfo ?? '';
            $this->headName = $this->editingOffice->HeadName ?? '';
            
            $this->showOfficeModal = true;
        }
    }    public function confirmDelete($itemId, $itemType)
    {
        $this->deletingItemId = $itemId;
        $this->deletingItemType = $itemType;
        $this->showDeleteConfirmModal = true;
    }
      public function closeDeleteConfirmModal()
    {
        // Close modal and reset properties
        $this->showDeleteConfirmModal = false;
        $this->deletingItemId = null;
        $this->deletingItemType = null;
        
        // Force UI refresh - this helps ensure lists are updated
        $this->dispatch('delete-modal-closed');
    }
      public function executeDelete()
    {
        if (!$this->deletingItemId || !$this->deletingItemType) {
            $this->dispatch('notify', [
                'message' => 'Error: Invalid delete request.',
                'type' => 'error'
            ]);
            $this->closeDeleteConfirmModal();
            return;
        }
        
        $success = false;
        $errorMessage = null;
        
        try {
            switch ($this->deletingItemType) {
                case 'office':
                    $success = $this->deleteOffice($this->deletingItemId);
                    break;
                case 'user':
                    $success = $this->deleteUser($this->deletingItemId);
                    break;
                case 'staff':
                    $success = $this->deleteStaff($this->deletingItemId);
                    break;
                default:
                    $errorMessage = 'Invalid item type';
            }
        } catch (\Exception $e) {
            $errorMessage = $e->getMessage();
        }
        
        // Close modal first to ensure it disappears
        $this->closeDeleteConfirmModal();
        
        // Dispatch refresh event based on item type
        if ($success) {
            $this->dispatch($this->deletingItemType . '-deleted');
        }
    }    protected function deleteOffice($officeId)
    {
        $office = Office::find($officeId);
        
        if (!$office) {
            $this->dispatch('notify', [
                'message' => 'Office not found!',
                'type' => 'error'
            ]);
            return false;
        }
        
        if ($office->staff()->count() > 0) {
            $this->dispatch('notify', [
                'message' => 'Cannot delete office with existing staff members!',
                'type' => 'error'
            ]);
            return false;
        }
        
        $office->delete();
        $this->dispatch('notify', [
            'message' => 'Office deleted successfully!',
            'type' => 'success'
        ]);
        
        return true;
    }

    public function openUserModal()
    {
        $this->resetUserForm();
        $this->showUserModal = true;    }
    
    public function closeUserModal()
    {
        $this->showUserModal = false;
        $this->resetUserForm(); // Reset form and close modal
        // Force UI refresh
        $this->dispatch('user-closed');
    }

    public function resetUserForm()
    {
        $this->editingUser = null;
        $this->userName = '';
        $this->userEmail = '';
        $this->userPassword = '';
        $this->userRole = '';
        $this->resetValidation();
    }

    public function saveUser()
    {
        $rules = [
            'userName' => 'required|string|max:255',
            'userRole' => 'required|exists:roles,RoleID',
        ];        if ($this->editingUser) {
            $rules['userEmail'] = 'required|email|unique:users,email,' . $this->editingUser->id;
            if (!empty($this->userPassword)) {
                $rules['userPassword'] = 'string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';
            }
        } else {
            $rules['userEmail'] = 'required|email|unique:users,email';
            $rules['userPassword'] = 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';
        }        $this->validate($rules);        // Get the role info to check for restricted roles
        $selectedRole = Role::find($this->userRole);
        if (!$selectedRole) {
            $this->dispatch('notify', [
                'message' => 'Invalid role selected.',
                'type' => 'error'
            ]);
            return;
        }

        // Check for restricted roles (Focal Person and RTS)
        if (in_array($selectedRole->RoleName, ['Focal Person', 'RTS'])) {
            // Check if the role already exists
            $existingUserWithRole = User::whereHas('roles', function($query) use ($selectedRole) {
                $query->where('roles.RoleID', $selectedRole->RoleID);
            })->first();            // For edits, exclude the current user being edited
            if ($this->editingUser && $existingUserWithRole && $existingUserWithRole->id != $this->editingUser->id) {
                $this->dispatch('notify', [
                    'message' => "Only one user can have the {$selectedRole->RoleName} role. {$existingUserWithRole->name} is already assigned this role.",
                    'type' => 'error'
                ]);
                $this->showUserModal = false;
                $this->resetUserForm();
                return;
            } 
            // For new users
            elseif (!$this->editingUser && $existingUserWithRole) {
                $this->dispatch('notify', [
                    'message' => "Only one user can have the {$selectedRole->RoleName} role. {$existingUserWithRole->name} is already assigned this role.",
                    'type' => 'error'
                ]);
                $this->showUserModal = false;
                $this->resetUserForm();
                return;
            }
        }
        
        // Additional check for PDO (Project Development Officer) if needed
        // Uncomment this if PDO role also should be restricted to one user
        /*
        if ($selectedRole->RoleName === 'Project Development Officer') {
            $existingPDO = User::whereHas('roles', function($query) use ($selectedRole) {
                $query->where('roles.RoleID', $selectedRole->RoleID);
            })->first();
            
            // For edits, exclude the current user being edited
            if ($this->editingUser && $existingPDO && $existingPDO->id != $this->editingUser->id) {
                session()->flash('error', "Only one user can have the Project Development Officer role. {$existingPDO->name} is already assigned this role.");
                return;
            }
            // For new users
            elseif (!$this->editingUser && $existingPDO) {
                session()->flash('error', "Only one user can have the Project Development Officer role. {$existingPDO->name} is already assigned this role.");
                return;
            }
        }
        */

        DB::beginTransaction();
        try {
            if ($this->editingUser) {
                // Update user
                $userData = [
                    'name' => $this->userName,
                    'email' => $this->userEmail,
                ];
                  if (!empty($this->userPassword)) {
                    $userData['password'] = Hash::make($this->userPassword);
                }
                
                $this->editingUser->update($userData);
                
                // Update role
                $this->editingUser->roles()->sync([$this->userRole]);
                
                $this->dispatch('notify', [
                    'message' => 'User updated successfully!', 
                    'type' => 'success'
                ]);
            } else {
                // Create user
                $user = User::create([
                    'name' => $this->userName,
                    'email' => $this->userEmail,
                    'password' => Hash::make($this->userPassword),
                    'email_verified_at' => now(),
                ]);
                  // Assign role
                $user->roles()->attach($this->userRole);
                  $this->dispatch('notify', [
                    'message' => 'User created successfully!', 
                    'type' => 'success'
                ]);
            }
            
            DB::commit();
            $this->showUserModal = false;
            $this->resetUserForm();
            // Force UI refresh
            $this->dispatch('user-saved');
        } catch (\Exception $e) {
            DB::rollback();
            $this->dispatch('notify', [
                'message' => 'Error saving user: ' . $e->getMessage(),
                'type' => 'error'
            ]);
            
            // Close modal even when there's an error
            $this->showUserModal = false;
            $this->resetUserForm();
        }
    }

    public function editUser($userId)
    {
        $this->editingUser = User::with('roles')->find($userId);
        
        if ($this->editingUser) {
            $this->userName = $this->editingUser->name;
            $this->userEmail = $this->editingUser->email;
            $this->userPassword = '';
            $this->userRole = $this->editingUser->roles->first()?->RoleID ?? '';
            
            $this->showUserModal = true;
        }
    }    protected function deleteUser($userId)
    {
        $user = User::find($userId);
        
        if (!$user) {
            $this->dispatch('notify', [
                'message' => 'User not found!',
                'type' => 'error'
            ]);
            return false;
        }
        
        // Check if user has staff records
        if ($user->staff()->count() > 0) {
            $this->dispatch('notify', [
                'message' => 'Cannot delete user with existing staff records!',
                'type' => 'error'
            ]);
            return false;
        }
        
        $user->delete();
        $this->dispatch('notify', [
            'message' => 'User deleted successfully!',
            'type' => 'success'
        ]);
        
        return true;
    }

    public function openStaffModal()
    {
        $this->resetStaffForm();
        $this->showStaffModal = true;    }
    
    public function closeStaffModal()
    {
        $this->showStaffModal = false;
        $this->resetStaffForm(); // Reset form and close modal
        // Force UI refresh
        $this->dispatch('staff-closed');
    }

    public function resetStaffForm()
    {
        $this->editingStaff = null;
        $this->staffFullName = '';
        $this->staffPosition = '';
        $this->staffContactDetails = '';
        $this->staffOfficeId = '';
        $this->staffUserId = '';
        $this->resetValidation();
    }

    public function saveStaff()
    {
        $this->validate([
            'staffFullName' => 'required|string|max:200',
            'staffPosition' => 'nullable|string|max:100',
            'staffContactDetails' => 'nullable|string|max:255',
            'staffOfficeId' => 'required|exists:offices,OfficeID',
            'staffUserId' => 'required|exists:users,id',
        ]);        // Check user role constraints
        $user = User::with('roles')->find($this->staffUserId);
        $userRole = $user->roles->first()?->RoleName;
        
        if (in_array($userRole, ['Focal Person', 'Project Development Officer', 'RTS'])) {
            // These roles can only have one staff record
            if ($user->staff()->where('StaffID', '!=', $this->editingStaff?->StaffID)->exists()) {
                $this->dispatch('notify', [
                    'message' => 'This user role can only be associated with one staff record!',
                    'type' => 'error'
                ]);
                $this->showStaffModal = false;
                $this->resetStaffForm();
                // Force UI refresh on error
                $this->dispatch('staff-error');
                return;
            }        } elseif ($userRole === 'Provincial Office') {
            // Provincial users can have multiple staff but only from the same office
            $existingStaff = $user->staff()->where('StaffID', '!=', $this->editingStaff?->StaffID)->first();
            if ($existingStaff && $existingStaff->OfficeID != $this->staffOfficeId) {
                $this->dispatch('notify', [
                    'message' => 'Provincial users can only be associated with staff from the same office!',
                    'type' => 'error'
                ]);
                $this->showStaffModal = false;
                $this->resetStaffForm();
                return;
            }
        }        if ($this->editingStaff) {
            $this->editingStaff->update([
                'FullName' => $this->staffFullName,
                'Position' => $this->staffPosition,
                'ContactDetails' => $this->staffContactDetails,
                'OfficeID' => $this->staffOfficeId,
                'UserID' => $this->staffUserId,
            ]);
            
            $this->dispatch('notify', [
                'message' => 'Staff updated successfully!',
                'type' => 'success'
            ]);
            
            $this->showStaffModal = false;
            $this->resetStaffForm();
        } else {            Staff::create([
                'FullName' => $this->staffFullName,
                'Position' => $this->staffPosition,
                'ContactDetails' => $this->staffContactDetails,
                'OfficeID' => $this->staffOfficeId,
                'UserID' => $this->staffUserId,
            ]);
            
            $this->dispatch('notify', [
                'message' => 'Staff created successfully!',
                'type' => 'success'
            ]);
            
            $this->showStaffModal = false;
            $this->resetStaffForm();
            // Force UI refresh
            $this->dispatch('staff-saved');
        }        // We've already closed it directly on success, this is just a backup
    }

    public function editStaff($staffId)
    {
        $this->editingStaff = Staff::find($staffId);
        
        if ($this->editingStaff) {
            $this->staffFullName = $this->editingStaff->FullName;
            $this->staffPosition = $this->editingStaff->Position ?? '';
            $this->staffContactDetails = $this->editingStaff->ContactDetails ?? '';
            $this->staffOfficeId = $this->editingStaff->OfficeID;
            $this->staffUserId = $this->editingStaff->UserID;
            
            $this->showStaffModal = true;
        }
    }    protected function deleteStaff($staffId)
    {
        $staff = Staff::find($staffId);
        
        if (!$staff) {
            $this->dispatch('notify', [
                'message' => 'Staff not found!',
                'type' => 'error'
            ]);
            return false;
        }
        
        $staff->delete();
        $this->dispatch('notify', [
            'message' => 'Staff deleted successfully!',
            'type' => 'success'
        ]);
        
        return true;
    }

    public function openPermissionModal($staffId)
    {
        $this->managingPermissionsStaff = Staff::with('permissions')->find($staffId);
        $this->selectedPermissions = $this->managingPermissionsStaff->permissions->pluck('PermissionID')->toArray();
        $this->showPermissionModal = true;    }
    
    public function closePermissionModal()
    {
        $this->showPermissionModal = false;
        $this->managingPermissionsStaff = null;
        $this->selectedPermissions = [];
        // Force UI refresh
        $this->dispatch('permissions-closed');
    }public function savePermissions()
    {
        try {
            if ($this->managingPermissionsStaff) {
                // Filter out 'View' permission since all staff have it by default
                $permissions = Permission::whereIn('PermissionID', $this->selectedPermissions)
                    ->where('PermissionName', '!=', 'View')
                    ->pluck('PermissionID')
                    ->toArray();
                  $this->managingPermissionsStaff->permissions()->sync($permissions);
                $this->dispatch('notify', [
                    'message' => 'Permissions updated successfully!',
                    'type' => 'success'
                ]);
                $this->showPermissionModal = false;
                $this->managingPermissionsStaff = null;
                $this->selectedPermissions = [];
                // Force UI refresh
                $this->dispatch('permissions-saved');
            }
        } catch (\Exception $e) {
            $this->dispatch('notify', [
                'message' => 'Error updating permissions: ' . $e->getMessage(),
                'type' => 'error'
            ]);
            // Close modal even on error
            $this->showPermissionModal = false;
            $this->managingPermissionsStaff = null;
            $this->selectedPermissions = [];
        }
    }

    private function getFilteredOffices()
    {
        $query = Office::with('staff');

        if ($this->search) {
            $query->where(function($q) {
                $q->where('OfficeName', 'like', '%' . $this->search . '%')
                  ->orWhere('Location', 'like', '%' . $this->search . '%')
                  ->orWhere('HeadName', 'like', '%' . $this->search . '%')
                  ->orWhere('ContactInfo', 'like', '%' . $this->search . '%');
            });
        }

        if ($this->officeTypeFilter) {
            $query->where('OfficeType', $this->officeTypeFilter);
        }

        return $query->orderBy('OfficeName')->paginate($this->perPage, ['*'], 'offices-page');
    }

    private function getFilteredUsers()
    {
        $query = User::with(['roles', 'staff.office']);

        if ($this->search) {
            $query->where(function($q) {
                $q->where('name', 'like', '%' . $this->search . '%')
                  ->orWhere('email', 'like', '%' . $this->search . '%');
            });
        }

        if ($this->roleFilter) {
            $query->whereHas('roles', function($q) {
                $q->where('roles.RoleID', $this->roleFilter);
            });
        }

        return $query->orderBy('name')->paginate($this->perPage, ['*'], 'users-page');
    }

    private function getFilteredStaff()
    {
        $query = Staff::with(['user', 'office', 'permissions']);

        if ($this->search) {
            $query->where(function($q) {
                $q->where('FullName', 'like', '%' . $this->search . '%')
                  ->orWhere('Position', 'like', '%' . $this->search . '%')
                  ->orWhere('ContactDetails', 'like', '%' . $this->search . '%')
                  ->orWhereHas('user', function($subQ) {
                      $subQ->where('name', 'like', '%' . $this->search . '%')
                           ->orWhere('email', 'like', '%' . $this->search . '%');
                  })
                  ->orWhereHas('office', function($subQ) {
                      $subQ->where('OfficeName', 'like', '%' . $this->search . '%');
                  });
            });
        }

        if ($this->officeFilter) {
            $query->where('OfficeID', $this->officeFilter);
        }

        if ($this->roleFilter) {
            $query->whereHas('user.roles', function($q) {
                $q->where('roles.RoleID', $this->roleFilter);
            });
        }

        return $query->orderBy('FullName')->paginate($this->perPage, ['*'], 'staff-page');
    }
    
    private function getFilteredLoginAttempts()
    {
        $query = LoginAttempt::query();

        if ($this->search) {
            $query->where(function($q) {
                $q->where('email', 'like', '%' . $this->search . '%')
                  ->orWhere('ip_address', 'like', '%' . $this->search . '%');
            });
        }

        if ($this->loginStatusFilter === 'success') {
            $query->where('successful', true);
        } elseif ($this->loginStatusFilter === 'failed') {
            $query->where('successful', false);
        }

        if ($this->loginDateFilter) {
            $query->whereDate('created_at', $this->loginDateFilter);
        }

        // Filter by existing users - only show login attempts for email addresses that exist in our users table
        if ($this->loginUserFilter === 'existing_users') {
            $query->whereIn('email', function($q) {
                $q->select('email')->from('users');
            });
        }

        return $query->orderBy('created_at', 'desc')->paginate($this->perPage, ['*'], 'login-attempts-page');
    }

    public function render()
    {
        $offices = $this->getFilteredOffices();
        $users = $this->getFilteredUsers();
        $staff = $this->getFilteredStaff();
        $roles = Role::orderBy('RoleName')->get();
        $allOffices = Office::orderBy('OfficeName')->get();
        $permissions = Permission::orderBy('PermissionName')->get();
        $loginAttempts = $this->getFilteredLoginAttempts();
        
        return view('livewire.focal.manage-users', [
            'offices' => $offices,
            'users' => $users,
            'staff' => $staff,
            'roles' => $roles,
            'allOffices' => $allOffices,
            'permissions' => $permissions,
            'loginAttempts' => $loginAttempts,
        ]);
    }
}
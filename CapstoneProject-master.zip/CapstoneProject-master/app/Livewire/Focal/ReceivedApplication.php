<?php

namespace App\Livewire\Focal;

use Livewire\Component;

class ReceivedApplication extends Component
{
    public function render()
    {
        return view('livewire.focal.received-application');
    }
} 
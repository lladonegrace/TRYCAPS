<?php

namespace App\Livewire\Focal;

use Livewire\Component;

class AssignedApplication extends Component
{
    public function render()
    {
        return view('livewire.focal.assigned-application');
    }
} 
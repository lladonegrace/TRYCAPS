<?php

namespace App\Livewire\Focal;

use Livewire\Component;

class IncomingApplications extends Component
{
    public function render()
    {
        return view('livewire.focal.incoming-applications');
    }
} 
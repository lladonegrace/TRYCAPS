<?php

namespace App\Livewire\Focal;

use Livewire\Component;

class ProgressMonitoring extends Component
{
    public function render()
    {
        return view('livewire.focal.progress-monitoring');
    }
} 
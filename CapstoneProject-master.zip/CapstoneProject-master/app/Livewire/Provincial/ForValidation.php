<?php

namespace App\Livewire\Provincial;

use Livewire\Component;

class ForValidation extends Component
{
    public function render()
    {
        return view('livewire.provincial.for-validation');
    }
} 
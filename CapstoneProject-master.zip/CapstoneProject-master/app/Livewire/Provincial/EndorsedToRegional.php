<?php

namespace App\Livewire\Provincial;

use Livewire\Component;

class EndorsedToRegional extends Component
{
    public function render()
    {
        return view('livewire.provincial.endorsed-to-regional');
    }
}
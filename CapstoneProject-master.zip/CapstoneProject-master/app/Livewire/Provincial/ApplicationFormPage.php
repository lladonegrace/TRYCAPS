<?php

namespace App\Livewire\Provincial;

use Livewire\Component;

class ApplicationFormPage extends Component
{
    public $currentStep = 1;
    public $totalSteps = 5;
    public $steps = [
        ['number' => 1, 'title' => 'Registration', 'description' => 'Basic info'],
        ['number' => 2, 'title' => 'Validation', 'description' => 'Review data'],
        ['number' => 3, 'title' => 'Visitation', 'description' => 'Site check'],
        ['number' => 4, 'title' => 'Generation', 'description' => 'Create docs'],
        ['number' => 5, 'title' => 'Compliance', 'description' => 'Final check']
    ];

    // Step 1 - Basic Information
    public $applicationTitle;
    public $category;
    public $description;

    // Step 2 - Cooperative Details
    public $cooperativeName;
    public $registrationNumber;
    public $contactPerson;
    public $phoneNumber;

    // Step 3 - Project Information
    public $projectType;
    public $expectedDuration;
    public $projectObjectives;

    // Step 4 - Financial Details
    public $totalBudget;
    public $requestedAmount;
    public $fundingSource;

    protected $rules = [
        // Step 1 Validation Rules
        'applicationTitle' => 'required|min:3',
        'category' => 'required',
        'description' => 'required|min:10',

        // Step 2 Validation Rules
        'cooperativeName' => 'required|min:3',
        'registrationNumber' => 'required',
        'contactPerson' => 'required',
        'phoneNumber' => 'required',

        // Step 3 Validation Rules
        'projectType' => 'required',
        'expectedDuration' => 'required',
        'projectObjectives' => 'required|min:10',

        // Step 4 Validation Rules
        'totalBudget' => 'required|numeric|min:0',
        'requestedAmount' => 'required|numeric|min:0|lte:totalBudget',
        'fundingSource' => 'required'
    ];

    public function mount()
    {
        // Initialize any default values here
    }

    public function nextStep()
    {
        // Validate current step
        $this->validateCurrentStep();
        
        if ($this->currentStep < $this->totalSteps) {
            $this->currentStep++;
        }
    }

    public function previousStep()
    {
        if ($this->currentStep > 1) {
            $this->currentStep--;
        }
    }

    public function validateCurrentStep()
    {
        $validationRules = [];
        
        switch ($this->currentStep) {
            case 1:
                $validationRules = [
                    'applicationTitle' => $this->rules['applicationTitle'],
                    'category' => $this->rules['category'],
                    'description' => $this->rules['description'],
                ];
                break;
            case 2:
                $validationRules = [
                    'cooperativeName' => $this->rules['cooperativeName'],
                    'registrationNumber' => $this->rules['registrationNumber'],
                    'contactPerson' => $this->rules['contactPerson'],
                    'phoneNumber' => $this->rules['phoneNumber'],
                ];
                break;
            case 3:
                $validationRules = [
                    'projectType' => $this->rules['projectType'],
                    'expectedDuration' => $this->rules['expectedDuration'],
                    'projectObjectives' => $this->rules['projectObjectives'],
                ];
                break;
            case 4:
                $validationRules = [
                    'totalBudget' => $this->rules['totalBudget'],
                    'requestedAmount' => $this->rules['requestedAmount'],
                    'fundingSource' => $this->rules['fundingSource'],
                ];
                break;
        }

        $this->validate($validationRules);
    }

    public function submitForm()
    {
        $this->validate();

        // TODO: Save the application data
        
        session()->flash('message', 'Application submitted successfully!');
        return redirect()->route('dashboard');
    }

    public function render()
    {
        return view('livewire.provincial.application-form-page')
            ->layout('layouts.app');
    }
}

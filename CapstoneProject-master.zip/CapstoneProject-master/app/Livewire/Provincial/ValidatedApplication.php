<?php

namespace App\Livewire\Provincial;

use Livewire\Component;

class ValidatedApplication extends Component
{
    public function render()
    {
        return view('livewire.provincial.validated-application');
    }
}
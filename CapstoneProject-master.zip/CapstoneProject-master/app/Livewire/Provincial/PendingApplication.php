<?php

namespace App\Livewire\Provincial;

use Livewire\Component;

class PendingApplication extends Component
{
    public function render()
    {
        return view('livewire.provincial.pending-application');
    }
} 
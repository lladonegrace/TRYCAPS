<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class SidebarNavigation extends Component
{
    public $userRole;
    public $navigationItems = [];

    public function mount()
    {
        $this->setUserRole();
        $this->setNavigationItems();
    }

    private function setUserRole()
    {
        $user = Auth::user();
        
        if ($user && $user->roles->isNotEmpty()) {
            $roleName = $user->roles->first()->RoleName;
            
            switch ($roleName) {
                case 'Project Development Officer':
                    $this->userRole = 'PDO';
                    break;
                case 'Focal Person':
                    $this->userRole = 'Focal';
                    break;
                case 'Provincial Office':
                    $this->userRole = 'Provincial';
                    break;
                case 'RTS':
                    $this->userRole = 'RTS';
                    break;
                default:
                    $this->userRole = 'Default';
            }
        }
    }

    private function setNavigationItems()
    {
        switch ($this->userRole) {
            case 'PDO':
                $this->navigationItems = [
                    ['name' => 'Dashboard', 'route' => 'dashboard', 'icon' => 'dashboard'],
                    ['name' => 'For Review', 'route' => 'dashboard.for-review', 'icon' => 'rate_review'],
                    ['name' => 'Under Review', 'route' => 'dashboard.under-review', 'icon' => 'pending'],
                    ['name' => 'Approved Application', 'route' => 'dashboard.approved-application', 'icon' => 'check_circle'],
                    ['name' => 'For Progress Monitoring', 'route' => 'dashboard.for-progress-monitoring', 'icon' => 'monitoring']
                ];
                break;

            case 'Focal':
                $this->navigationItems = [
                    ['name' => 'Dashboard', 'route' => 'dashboard', 'icon' => 'dashboard'],
                    ['name' => 'All Applications', 'route' => 'dashboard.all-applications', 'icon' => 'apps'],
                    ['name' => 'Incoming Applications', 'route' => 'dashboard.incoming-applications', 'icon' => 'inbox'],
                    ['name' => 'Received Application', 'route' => 'dashboard.received-application', 'icon' => 'mark_email_read'],
                    ['name' => 'Assigned Application', 'route' => 'dashboard.assigned-application', 'icon' => 'assignment_ind'],
                    ['name' => 'For Progress Monitoring', 'route' => 'dashboard.progress-monitoring', 'icon' => 'monitoring'],
                    ['name' => 'Manage Users', 'route' => 'dashboard.manage-users', 'icon' => 'manage_accounts']
                ];
                break;

            case 'Provincial':
                $this->navigationItems = [
                    ['name' => 'Dashboard', 'route' => 'dashboard', 'icon' => 'dashboard'],
                    ['name' => 'For Validation', 'route' => 'dashboard.for-validation', 'icon' => 'pending_actions'],
                    ['name' => 'Validated Application', 'route' => 'dashboard.validated-application', 'icon' => 'task_alt'],
                    ['name' => 'Pending Application', 'route' => 'dashboard.pending-application', 'icon' => 'schedule'],
                    ['name' => 'Endorsed to Regional', 'route' => 'dashboard.endorsed-to-regional', 'icon' => 'grading']
                ];
                break;

            case 'RTS':
                $this->navigationItems = [
                    ['name' => 'Dashboard', 'route' => 'dashboard', 'icon' => 'dashboard'],
                    ['name' => 'All Applications', 'route' => 'dashboard.rts-all-applications', 'icon' => 'apps'],
                    ['name' => 'For Eligibility Check', 'route' => 'dashboard.for-eligibility-check', 'icon' => 'fact_check'],
                    ['name' => 'Pending Application', 'route' => 'dashboard.rts-pending-application', 'icon' => 'schedule']
                ];
                break;

            default:
                $this->navigationItems = [
                    ['name' => 'Dashboard', 'route' => 'dashboard', 'icon' => 'dashboard']
                ];
        }
    }



    public function render()
    {
        return view('livewire.sidebar-navigation');
    }
}
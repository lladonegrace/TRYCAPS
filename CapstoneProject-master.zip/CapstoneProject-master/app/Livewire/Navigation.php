<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class Navigation extends Component
{
    // Simplified navigation component that uses role-based partials

    public function render()
    {
        $user = Auth::user();
        $role = null;
        
        // Get the user's first role name and map to navigation identifier
        if ($user && $user->roles->isNotEmpty()) {
            $roleName = $user->roles->first()->RoleName;
            
            switch ($roleName) {
                case 'Project Development Officer':
                    $role = 'PDO';
                    break;
                case 'Focal Person':
                    $role = 'Focal';
                    break;
                case 'Provincial Office':
                    $role = 'Provincial';
                    break;
                case 'RTS': 
                    $role = 'RTS';
                    break;
                default:
                    $role = 'Default';
            }
        }

        return view('livewire.navigation', compact('role'));
    }
}

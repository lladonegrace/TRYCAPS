<?php

namespace App\Livewire\Pdo;

use Livewire\Component;

class ApprovedApplication extends Component
{
    public function render()
    {
        return view('livewire.pdo.approved-application');
    }
} 
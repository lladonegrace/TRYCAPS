<?php

namespace App\Livewire\Pdo;

use Livewire\Component;
use Livewire\WithPagination;

class ForReview extends Component
{
    use WithPagination;

    public $search = '';
    public $statusFilter = '';
    public $provinceFilter = '';
    public $sortBy = 'created_at';
    public $sortDirection = 'desc';
    public $perPage = 10;

    protected $queryString = [
        'search' => ['except' => ''],
        'statusFilter' => ['except' => ''],
        'provinceFilter' => ['except' => ''],
        'sortBy' => ['except' => 'created_at'],
        'sortDirection' => ['except' => 'desc'],
    ];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingStatusFilter()
    {
        $this->resetPage();
    }

    public function updatingProvinceFilter()
    {
        $this->resetPage();
    }

    public function sortBy($field)
    {
        if ($this->sortBy === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortBy = $field;
            $this->sortDirection = 'asc';
        }
    }

    public function clearFilters()
    {
        $this->reset(['search', 'statusFilter', 'provinceFilter']);
        $this->resetPage();
    }

    public function render()
    {
        // Mock data for demonstration
        $applications = collect([
            ['id' => 1, 'title' => 'Coconut Processing Facility', 'cooperative' => 'Albay Farmers Cooperative', 'province' => 'Albay', 'amount' => 2500000, 'submitted_at' => '2024-01-15', 'type' => 'Infrastructure', 'priority' => 'High'],
            ['id' => 2, 'title' => 'Farm Equipment Purchase', 'cooperative' => 'Camarines Norte Multi-Purpose Coop', 'province' => 'Camarines Norte', 'amount' => 1200000, 'submitted_at' => '2024-01-14', 'type' => 'Equipment', 'priority' => 'Medium'],
            ['id' => 3, 'title' => 'Irrigation System Upgrade', 'cooperative' => 'Sorsogon Farmers United', 'province' => 'Sorsogon', 'amount' => 3000000, 'submitted_at' => '2024-01-13', 'type' => 'Infrastructure', 'priority' => 'High'],
            ['id' => 4, 'title' => 'Storage Facility Construction', 'cooperative' => 'Camarines Sur Cooperative', 'province' => 'Camarines Sur', 'amount' => 1800000, 'submitted_at' => '2024-01-12', 'type' => 'Infrastructure', 'priority' => 'Medium'],
            ['id' => 5, 'title' => 'Training and Capacity Building', 'cooperative' => 'Catanduanes Coop Alliance', 'province' => 'Catanduanes', 'amount' => 500000, 'submitted_at' => '2024-01-11', 'type' => 'Training', 'priority' => 'Low'],
            ['id' => 6, 'title' => 'Livestock Development Program', 'cooperative' => 'Masbate Livestock Coop', 'province' => 'Masbate', 'amount' => 2200000, 'submitted_at' => '2024-01-10', 'type' => 'Livestock', 'priority' => 'High'],
        ]);

        // Apply filters
        if ($this->search) {
            $applications = $applications->filter(function ($app) {
                return stripos($app['title'], $this->search) !== false ||
                       stripos($app['cooperative'], $this->search) !== false;
            });
        }

        if ($this->provinceFilter) {
            $applications = $applications->where('province', $this->provinceFilter);
        }

        // Sort
        $applications = $applications->sortBy($this->sortBy, SORT_REGULAR, $this->sortDirection === 'desc');

        // Paginate manually for demo
        $currentPage = request()->get('page', 1);
        $offset = ($currentPage - 1) * $this->perPage;
        $paginatedApps = $applications->slice($offset, $this->perPage);

        return view('livewire.pdo.for-review', [
            'applications' => $paginatedApps,
            'total' => $applications->count(),
            'provinces' => ['Albay', 'Camarines Norte', 'Camarines Sur', 'Sorsogon', 'Catanduanes', 'Masbate']
        ]);
    }
} 
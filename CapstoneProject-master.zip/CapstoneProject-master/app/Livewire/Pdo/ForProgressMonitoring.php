<?php

namespace App\Livewire\Pdo;

use Livewire\Component;

class ForProgressMonitoring extends Component
{
    public function render()
    {
        return view('livewire.pdo.for-progress-monitoring');
    }
} 
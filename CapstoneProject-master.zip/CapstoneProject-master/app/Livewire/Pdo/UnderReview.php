<?php

namespace App\Livewire\Pdo;

use Livewire\Component;

class UnderReview extends Component
{
    public function render()
    {
        return view('livewire.pdo.under-review');
    }
}
<?php

namespace App\Livewire\Pdo;

use Livewire\Component;

class Dashboard extends Component
{
    public function render()
    {
        return view('livewire.pdo.dashboard');
    }
} 
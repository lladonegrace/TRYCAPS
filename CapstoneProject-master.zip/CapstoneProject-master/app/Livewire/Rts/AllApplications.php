<?php

namespace App\Livewire\Rts;

use Livewire\Component;

class AllApplications extends Component
{
    public function render()
    {
        return view('livewire.rts.all-applications');
    }
}

<?php

namespace App\Livewire\Rts;

use Livewire\Component;
use Illuminate\Support\Facades\Log;

class EligibilityCheckDetails extends Component
{    public $applicationId;
    public $application;
    public $registeredCount = 0;
    public $totalCount = 100;
    
    // We're making the id parameter optional to solve the dependency injection issue
    public function mount($id = null)
    {
        // Log the ID parameter for debugging
        \Log::info('EligibilityCheckDetails mount method called with ID: ' . ($id ?? 'null'));
        
        // If id is not provided through the mount method, check if it's in the route parameters
        if ($id === null) {
            $id = request()->route('id');
            \Log::info('ID from route: ' . ($id ?? 'null'));
        }
        
        $this->applicationId = $id ?? 1; // Default to 1 if no ID is provided
        \Log::info('Final application ID: ' . $this->applicationId);
        
        // In a real app, you would fetch the application data from the database
        // For this dummy implementation, we'll just use the ID
        \Log::info("Loading eligibility check details for application ID: {$this->applicationId}");
        
        // Mock application data
        $this->application = [
            'id' => $this->applicationId,
            'reference_id' => 'APP-2025-' . str_pad($this->applicationId, 4, '0', STR_PAD_LEFT),
            'title' => 'Coconut Farmers Registration - Batch ' . $this->applicationId,
            'applicant_name' => 'Juan Dela Cruz',
            'province' => 'Albay',
            'status' => 'For Eligibility Check',
        ];
        
        // Mock registered count (random between 0 and 100)
        $this->registeredCount = rand(0, 100);
    }    public function goBack()
    {
        \Log::info('Going back to For Eligibility Check page');
        return redirect()->route('dashboard.for-eligibility-check');
    }
    
    public function generateCertificate()
    {
        // In a real app, you would generate the certificate
        // For this dummy implementation, we'll just log it
        Log::info("Generating certificate for application ID: {$this->applicationId}");
        
        // Show a notification to the user
        $this->dispatch('notify', [
            'type' => 'success',
            'title' => 'Certificate Generated',
            'message' => 'The certificate has been successfully generated.',
        ]);
    }
    
    public function render()
    {
        return view('livewire.rts.eligibility-check-details');
    }
}

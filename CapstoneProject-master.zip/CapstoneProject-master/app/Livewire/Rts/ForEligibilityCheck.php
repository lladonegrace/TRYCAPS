<?php

namespace App\Livewire\Rts;

use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Log;

class ForEligibilityCheck extends Component
{
    use WithPagination;
    
    public $search = '';
    public $sortField = 'reference_id';
    public $sortDirection = 'asc';
    public $perPage = 10;
    public $filterStatus = '';
    public $filterProvince = '';
    public $page = 1;
    
    protected $queryString = [
        'search' => ['except' => ''],
        'sortField' => ['except' => 'reference_id'],
        'sortDirection' => ['except' => 'asc'],
        'perPage' => ['except' => 10],
        'filterStatus' => ['except' => ''],
        'filterProvince' => ['except' => ''],
        'page' => ['except' => 1],
    ];
    
    // Dummy provinces for filter
    public $provinces = [
        'Albay', 'Batangas', 'Benguet', 'Bulacan', 'Cavite', 
        'Cebu', 'Davao del Sur', 'Iloilo', 'Laguna', 'Pampanga'
    ];
    
    // Dummy data for the table
    public $applications = [
        [
            'id' => 1,
            'reference_id' => 'APP-2025-0001',
            'title' => 'Organic Rice Farming Cooperative',
            'applicant_name' => 'Juan dela Cruz',
            'province' => 'Laguna',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-15',
        ],
        [
            'id' => 2,
            'reference_id' => 'APP-2025-0002',
            'title' => 'Community Fish Processing Center',
            'applicant_name' => 'Maria Santos',
            'province' => 'Batangas',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-18',
        ],
        [
            'id' => 3,
            'reference_id' => 'APP-2025-0003',
            'title' => 'Indigenous Weaving Collective',
            'applicant_name' => 'Pedro Reyes',
            'province' => 'Benguet',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-20',
        ],
        [
            'id' => 4,
            'reference_id' => 'APP-2025-0004',
            'title' => 'Urban Vertical Farming Initiative',
            'applicant_name' => 'Ana Gonzales',
            'province' => 'Cebu',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-22',
        ],
        [
            'id' => 5,
            'reference_id' => 'APP-2025-0005',
            'title' => 'Rural Healthcare Mobile Clinic',
            'applicant_name' => 'Roberto Tan',
            'province' => 'Davao del Sur',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-25',
        ],
        [
            'id' => 6,
            'reference_id' => 'APP-2025-0006',
            'title' => 'Sustainable Bamboo Housing Project',
            'applicant_name' => 'Elena Magsaysay',
            'province' => 'Iloilo',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-28',
        ],
        [
            'id' => 7,
            'reference_id' => 'APP-2025-0007',
            'title' => 'Community Solar Power Cooperative',
            'applicant_name' => 'Miguel Bautista',
            'province' => 'Albay',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-05-30',
        ],
        [
            'id' => 8,
            'reference_id' => 'APP-2025-0008',
            'title' => 'Agricultural Waste to Energy Facility',
            'applicant_name' => 'Sofia Cruz',
            'province' => 'Pampanga',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-06-02',
        ],
        [
            'id' => 9,
            'reference_id' => 'APP-2025-0009',
            'title' => 'Coastal Mangrove Restoration Program',
            'applicant_name' => 'Luis Mendoza',
            'province' => 'Cavite',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-06-05',
        ],
        [
            'id' => 10,
            'reference_id' => 'APP-2025-0010',
            'title' => 'Eco-Tourism Development Project',
            'applicant_name' => 'Carmen Villanueva',
            'province' => 'Bulacan',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-06-08',
        ],
        [
            'id' => 11,
            'reference_id' => 'APP-2025-0011',
            'title' => 'Traditional Herbal Medicine Preservation',
            'applicant_name' => 'Antonio Pascual',
            'province' => 'Laguna',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-06-10',
        ],
        [
            'id' => 12,
            'reference_id' => 'APP-2025-0012',
            'title' => 'Youth Skills Development Center',
            'applicant_name' => 'Rosario Reyes',
            'province' => 'Cebu',
            'status' => 'For Eligibility Check',
            'date_submitted' => '2025-06-12',
        ],
    ];
    
    public function mount()
    {
        Log::info('ForEligibilityCheck component mounted');
    }
    
    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortField = $field;
            $this->sortDirection = 'asc';
        }
    }
    
    public function setPage($page)
    {
        $this->page = $page;
    }
    
    public function resetPage()
    {
        $this->page = 1;
    }
    
    public function updatingSearch()
    {
        $this->resetPage();
    }
    
    public function updatingFilterStatus()
    {
        $this->resetPage();
    }
    
    public function updatingFilterProvince()
    {
        $this->resetPage();
    }
    
    public function getApplicationsProperty()
    {
        $apps = collect($this->applications);
        
        // Apply search filter
        if ($this->search) {
            $apps = $apps->filter(function($item) {
                return 
                    stripos($item['reference_id'], $this->search) !== false ||
                    stripos($item['title'], $this->search) !== false ||
                    stripos($item['applicant_name'], $this->search) !== false;
            });
        }
        
        // Apply province filter
        if ($this->filterProvince) {
            $apps = $apps->filter(function($item) {
                return $item['province'] === $this->filterProvince;
            });
        }
        
        // Apply status filter
        if ($this->filterStatus) {
            $apps = $apps->filter(function($item) {
                return $item['status'] === $this->filterStatus;
            });
        }
        
        // Apply sorting
        $apps = $apps->sortBy([$this->sortField, $this->sortDirection === 'asc' ? 'asc' : 'desc']);
        
        // Return paginated results
        return $apps->values()->all();
    }
    
    public function getPaginatedApplicationsProperty()
    {
        // Manual pagination logic
        $page = $this->page ?: 1;
        $perPage = $this->perPage;
        $apps = $this->getApplicationsProperty(); // Call the method instead of accessing a property
        
        $total = count($apps);
        $items = array_slice($apps, ($page - 1) * $perPage, $perPage);
        
        return [
            'data' => $items,
            'links' => [
                'current_page' => $page,
                'last_page' => ceil($total / $perPage),
                'per_page' => $perPage,
                'total' => $total,
            ]
        ];
    }
    
    public function viewApplication($id)
    {
        // Navigate to the eligibility check details page
        return redirect()->route('rts.eligibility-check-details', ['id' => $id]);
    }
    
    public function editApplication($id)
    {
        // This would normally navigate to an edit page
        $this->dispatch('showAlert', ['title' => 'Edit Application', 'message' => "Editing application {$id}", 'type' => 'info']);
    }
    
    public function render()
    {
        Log::info('ForEligibilityCheck component rendering');
        
        $paginatedApplications = $this->getPaginatedApplicationsProperty();
        
        return view('livewire.rts.for-eligibility-check', [
            'applications' => $paginatedApplications['data'],
            'links' => $paginatedApplications['links'],
        ]);
    }
}

<?php

namespace App\Livewire\Rts;

use Livewire\Component;

class Dashboard extends Component
{
    public function render()
    {
        return view('livewire.rts.dashboard');
    }
} 
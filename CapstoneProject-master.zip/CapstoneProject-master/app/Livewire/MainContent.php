<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\On;

class MainContent extends Component
{
    public $activeTab = 'dashboard';
    public $userRole;
    public $dashboardContent;

    public function mount()
    {
        $this->activeTab = request()->route()->getName() ?: 'dashboard';
        $this->userRole = $this->getUserRole();
        $this->setDashboardContent();
    }

    private function getUserRole()
    {
        $user = Auth::user();
        
        if ($user->hasRole('Focal Person')) {
            return 'focal-person';
        } elseif ($user->hasRole('Provincial Office')) {
            return 'provincial-office';
        } elseif ($user->hasRole('Project Development Officer')) {
            return 'project-development-officer';
        }
        
        return 'default';
    }

    private function setDashboardContent()
    {
        switch ($this->userRole) {
            case 'focal-person':
                $this->dashboardContent = [
                    'title' => 'Focal Person Dashboard',
                    'widgets' => [
                        ['title' => 'Pending Applications', 'count' => 25, 'color' => 'blue', 'icon' => 'pending_actions'],
                        ['title' => 'Approved Applications', 'count' => 142, 'color' => 'green', 'icon' => 'task_alt'],
                        ['title' => 'Recent Activities', 'count' => 8, 'color' => 'yellow', 'icon' => 'notifications'],
                        ['title' => 'Monthly Reports', 'count' => 3, 'color' => 'purple', 'icon' => 'assessment']
                    ]
                ];
                break;
                
            case 'provincial-office':
                $this->dashboardContent = [
                    'title' => 'Provincial Office Dashboard',
                    'widgets' => [
                        ['title' => 'Office Statistics', 'count' => 12, 'color' => 'purple', 'icon' => 'business'],
                        ['title' => 'Project Overview', 'count' => 45, 'color' => 'indigo', 'icon' => 'view_list'],
                        ['title' => 'Staff Performance', 'count' => 89, 'color' => 'pink', 'icon' => 'groups'],
                        ['title' => 'Budget Allocation', 'count' => '₱2.5M', 'color' => 'emerald', 'icon' => 'account_balance']
                    ]
                ];
                break;
                
            case 'project-development-officer':
                $this->dashboardContent = [
                    'title' => 'Project Development Officer Dashboard',
                    'widgets' => [
                        ['title' => 'Project Progress', 'count' => '75%', 'color' => 'emerald', 'icon' => 'engineering'],
                        ['title' => 'Development Tasks', 'count' => 18, 'color' => 'cyan', 'icon' => 'task'],
                        ['title' => 'Resource Allocation', 'count' => 6, 'color' => 'teal', 'icon' => 'account_balance'],
                        ['title' => 'Technical Reviews', 'count' => 11, 'color' => 'orange', 'icon' => 'rate_review']
                    ]
                ];
                break;
                
            default:
                $this->dashboardContent = [
                    'title' => 'Dashboard',
                    'widgets' => [
                        ['title' => 'Welcome', 'count' => 'User', 'color' => 'gray', 'icon' => 'dashboard']
                    ]
                ];
        }
    }

    #[On('activeTabChanged')]
    public function updateActiveTab($tab)
    {
        $this->activeTab = $tab;
    }

    public function render()
    {
        return view('livewire.main-content', [
            'dashboardContent' => $this->dashboardContent
        ]);
    }
}
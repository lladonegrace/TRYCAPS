<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Livewire\Provincial\ApplicationFormPage;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return redirect('/dashboard');
});

Route::middleware(['auth', 'verified'])->group(function () {
    // Main Dashboard Route
    Route::get('/dashboard', function () {
        return view('dashboard', ['component' => 'dashboard']);
    })->name('dashboard');

    // Provincial Office Routes
    Route::get('/provincial/for-validation', function () {
        return view('dashboard', ['component' => 'for-validation']);
    })->name('dashboard.for-validation');

    Route::get('/provincial/validated-application', function () {
        return view('dashboard', ['component' => 'validated-application']);
    })->name('dashboard.validated-application');

    Route::get('/provincial/pending-application', function () {
        return view('dashboard', ['component' => 'pending-application']);
    })->name('dashboard.pending-application');

    Route::get('/provincial/endorsed-to-regional', function () {
        return view('dashboard', ['component' => 'endorsed-to-regional']);
    })->name('dashboard.endorsed-to-regional');

    // Application Form Route
    Route::get('/applications/create', ApplicationFormPage::class)->name('applications.create');






    // Focal Person Routes
    Route::get('/dashboard/all-applications', function () {
        return view('dashboard', ['component' => 'all-applications']);
    })->name('dashboard.all-applications');

    Route::get('/dashboard/incoming-applications', function () {
        return view('dashboard', ['component' => 'incoming-applications']);
    })->name('dashboard.incoming-applications');

    Route::get('/dashboard/received-application', function () {
        return view('dashboard', ['component' => 'received-application']);
    })->name('dashboard.received-application');

    Route::get('/dashboard/assigned-application', function () {
        return view('dashboard', ['component' => 'assigned-application']);
    })->name('dashboard.assigned-application');

    Route::get('/dashboard/progress-monitoring', function () {
        return view('dashboard', ['component' => 'progress-monitoring']);
    })->name('dashboard.progress-monitoring');

    Route::get('/dashboard/manage-users', function () {
        return view('dashboard', ['component' => 'manage-users']);
    })->name('dashboard.manage-users');

    // PDO Routes
    Route::get('/dashboard/for-review', function () {
        return view('dashboard', ['component' => 'for-review']);
    })->name('dashboard.for-review');

    Route::get('/dashboard/under-review', function () {
        return view('dashboard', ['component' => 'under-review']);
    })->name('dashboard.under-review');

    Route::get('/dashboard/approved-application', function () {
        return view('dashboard', ['component' => 'approved-application']);
    })->name('dashboard.approved-application');

    Route::get('/dashboard/for-progress-monitoring', function () {
        return view('dashboard', ['component' => 'for-progress-monitoring']);
    })->name('dashboard.for-progress-monitoring');

    // RTS Routes
    Route::get('/dashboard/for-eligibility-check', function () {
        return view('dashboard', ['component' => 'for-eligibility-check']);
    })->name('dashboard.for-eligibility-check');
    
    Route::get('/dashboard/for-eligibility-check/{id}/details', function ($id) {
        \Log::info('Route for eligibility check details with ID: ' . $id);
        return view('dashboard', [
            'component' => 'eligibility-check-details', 
            'id' => $id
        ]);
    })->name('rts.eligibility-check-details');

    Route::get('/dashboard/rts-all-applications', function () {
        return view('dashboard', ['component' => 'rts-all-applications']);
    })->name('dashboard.rts-all-applications');

    Route::get('/dashboard/rts-pending-application', function () {
        return view('dashboard', ['component' => 'rts-pending-application']);
    })->name('dashboard.rts-pending-application');

    // Profile Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

});

require __DIR__.'/auth.php';
